/*****************************************************************************/
/*                            Cantata Test Script                            */
/*****************************************************************************/
/*
 *    Filename: atest_RBAPLCUST_RoutineControl_ESPSpecialDrive_Suzuki.c
 *    Author: nhi5hc
 *    Generated on: 09-Apr-2020 18:14:23
 *    Generated from: RBAPLCUST_RoutineControl_ESPSpecialDrive_Suzuki.c
 */
/*****************************************************************************/
/* Environment Definition                                                    */
/*****************************************************************************/

#define TEST_SCRIPT_GENERATOR 2

/* Include files from software under test */
#include "Compiler.h"
#include "RBAPLCUST_RoutineControl.h"
#include "RBAPLCUST_RoutineControl_Suzuki.h"
#include "RBAPLCUST_RoutineControlInterface_Suzuki.h"
#include "RBAPLCUST_RoutineControl_ConditionMonitoring_Suzuki.h"
#include "Dem_DTCGroup.h"
#include "Dem_Types.h"
#include "RBAPLCUST_FreezeFrameData_Suzuki.h"

#define CANTATA_DEFAULT_VALUE 0 /* Default value of variables & stub returns */

#include <cantpp.h>  /* Cantata Directives */
/* pragma qas cantata testscript start */
/*****************************************************************************/
/* Global Data Definitions                                                   */
/*****************************************************************************/

/* Global Functions */
extern Std_ReturnType RbAplCust_ESPSpecialDrive_Start(uint8 dataIn1, Dcm_OpStatusType OpStatus, Dcm_NegativeResponseCodeType * const ErrorCode);
extern Std_ReturnType RbAplCust_ESPSpecialDrive_Stop(uint8 dataIn1, Dcm_OpStatusType OpStatus, Dcm_NegativeResponseCodeType * const ErrorCode);
extern Std_ReturnType RbAplCust_ESPSpecialDriveEntryCheck();
extern ForceClearAllDTC_State_EN RbAplCust_ForceClearDTCRun();
extern Std_ReturnType RbAplCust_IsValidForceClearDTC(Dem_DtcCodeType storedDtc);
void RBSYS_EnterCommonLockSysfast();
void RBSYS_ExitCommonLockSysfast();
uint8 RbAplCust_ReadyToStartRoutine(RoutineControl_SupportedRIDs_EN l_EOLProcess);
void RbAplCust_EolProcessStop();
boolean FUN_HMIIgOn2sCheck_B();
Dem_ReturnControlDTCSettingType Dem_DisableDTCSetting(Dem_DTCGroupType DTCGroup, Dem_DTCKindType DTCKind);
void RbAplCust_EraseFreezeFrameDataInfo();
Std_ReturnType RbAplCust_CheckRoutineOperationVoltage();
Std_ReturnType RbAplCust_CheckAllWheelSpeed(uint16_t param_1);
void Dem_EvMemEventMemoryLocIteratorNew(uint16_least * LocId, uint16_least MemId);
Dem_boolean_least Dem_EvMemEventMemoryLocIteratorIsValid(const uint16_least * LocId, uint16_least MemId);
Dem_EventIdType Dem_EvMemGetEventMemEventId(uint16_least LocId);
Dem_DtcIdType Dem_DtcIdFromEventId(Dem_EventIdType id);
Dem_DtcCodeType Dem_DtcGetCode(Dem_DtcIdType dtcId);
Dem_boolean_least Dem_isDtcIdValid(Dem_DtcIdType id);
void Dem_EvMemEventMemoryLocIteratorNext(uint16_least * LocId, uint16_least MemId);
Dem_ReturnClearDTCType Dem_ClearDTC(uint32 DTC, Dem_DTCFormatType DTCFormat, Dem_DTCOriginType DTCOrigin);

/* Global data */
volatile MESGType_MESG_DCOM_ProcessSelection_En MESG_MESG_DCOM_ProcessSelection_En;
volatile MESGType_MESG_DCOM_EOLStopRequest_B MESG_MESG_DCOM_EOLStopRequest_B;
RoutineControl_ActuationInfo_st g_EOLActuationSetting_St;
RoutineControl_State_en g_RoutineControlState_En;
extern ForceClearAllDTC_State_EN g_ForceClearDtcState_En;
extern ForceClearSingleDTC_State_EN g_ClearSingleDtcState_En;
extern uint16_least g_ForceClearDtc_EventMemLocation_u16;
extern uint16_least g_ForceClearDtc_EventID_u16;
extern Dem_DtcIdType g_ForceClearDtc_DTCId_u16;
extern Dem_DtcCodeType g_ForceClearDtc_DTCCode_u16;
extern BOOL g_ForceClearDtc_FailStatus_b;
extern Dcm_ReturnClearDTCType_tu8 g_DemClearDTCReturnStatus_u8;
extern Dem_DtcCodeType g_ValidDTCList_ForceClearDTC[26];
extern ForceClear_Check_ReadyToStartRoutine_State_EN * LOCAL_VARIABLE_ACCESSOR(RBAPLCUST_RoutineControl_ESPSpecialDrive_Suzuki, RbAplCust_ESPSpecialDrive_Start, ReadyToStartRoutine_State_EN);
//User define
Dcm_NegativeResponseCodeType map_ErrorCode;

/* Expected variables for global data */
MESGType_MESG_DCOM_ProcessSelection_En expected_MESG_MESG_DCOM_ProcessSelection_En;
MESGType_MESG_DCOM_EOLStopRequest_B expected_MESG_MESG_DCOM_EOLStopRequest_B;
RoutineControl_ActuationInfo_st expected_g_EOLActuationSetting_St;
RoutineControl_State_en expected_g_RoutineControlState_En;
ForceClearAllDTC_State_EN expected_g_ForceClearDtcState_En;
ForceClearSingleDTC_State_EN expected_g_ClearSingleDtcState_En;
uint16_least expected_g_ForceClearDtc_EventMemLocation_u16;
uint16_least expected_g_ForceClearDtc_EventID_u16;
Dem_DtcIdType expected_g_ForceClearDtc_DTCId_u16;
Dem_DtcCodeType expected_g_ForceClearDtc_DTCCode_u16;
BOOL expected_g_ForceClearDtc_FailStatus_b;
Dcm_ReturnClearDTCType_tu8 expected_g_DemClearDTCReturnStatus_u8;
Dem_DtcCodeType expected_g_ValidDTCList_ForceClearDTC[26];

/* This function initialises global data to default values. This function       */
/* is called by every test case so must not contain test case specific settings */
static void initialise_global_data(){
    TEST_SCRIPT_WARNING("Verify initialise_global_data()\n");
        INITIALISE(MESG_MESG_DCOM_ProcessSelection_En);
    INITIALISE(MESG_MESG_DCOM_EOLStopRequest_B);
    INITIALISE(g_EOLActuationSetting_St);
    INITIALISE(g_RoutineControlState_En);
    INITIALISE(g_ForceClearDtcState_En);
    INITIALISE(g_ClearSingleDtcState_En);
    INITIALISE(g_ForceClearDtc_EventMemLocation_u16);
    INITIALISE(g_ForceClearDtc_EventID_u16);
    INITIALISE(g_ForceClearDtc_DTCId_u16);
    INITIALISE(g_ForceClearDtc_DTCCode_u16);
    INITIALISE(g_ForceClearDtc_FailStatus_b);
    INITIALISE(g_DemClearDTCReturnStatus_u8);
    INITIALISE(g_ValidDTCList_ForceClearDTC);
}

/* This function copies the global data settings into expected variables for */
/* use in check_global_data(). It is called by every test case so must not   */
/* contain test case specific settings.                                      */
static void initialise_expected_global_data(){
    TEST_SCRIPT_WARNING("Verify initialise_expected_global_data()\n");
    COPY_TO_EXPECTED(MESG_MESG_DCOM_ProcessSelection_En, expected_MESG_MESG_DCOM_ProcessSelection_En);
    COPY_TO_EXPECTED(MESG_MESG_DCOM_EOLStopRequest_B, expected_MESG_MESG_DCOM_EOLStopRequest_B);
    COPY_TO_EXPECTED(g_EOLActuationSetting_St, expected_g_EOLActuationSetting_St);
    COPY_TO_EXPECTED(g_RoutineControlState_En, expected_g_RoutineControlState_En);
    COPY_TO_EXPECTED(g_ForceClearDtcState_En, expected_g_ForceClearDtcState_En);
    COPY_TO_EXPECTED(g_ClearSingleDtcState_En, expected_g_ClearSingleDtcState_En);
    COPY_TO_EXPECTED(g_ForceClearDtc_EventMemLocation_u16, expected_g_ForceClearDtc_EventMemLocation_u16);
    COPY_TO_EXPECTED(g_ForceClearDtc_EventID_u16, expected_g_ForceClearDtc_EventID_u16);
    COPY_TO_EXPECTED(g_ForceClearDtc_DTCId_u16, expected_g_ForceClearDtc_DTCId_u16);
    COPY_TO_EXPECTED(g_ForceClearDtc_DTCCode_u16, expected_g_ForceClearDtc_DTCCode_u16);
    COPY_TO_EXPECTED(g_ForceClearDtc_FailStatus_b, expected_g_ForceClearDtc_FailStatus_b);
    COPY_TO_EXPECTED(g_DemClearDTCReturnStatus_u8, expected_g_DemClearDTCReturnStatus_u8);
    COPY_TO_EXPECTED(g_ValidDTCList_ForceClearDTC, expected_g_ValidDTCList_ForceClearDTC);
}

/* This function checks global data against the expected values. */
static void check_global_data(){
    TEST_SCRIPT_WARNING("Verify check_global_data()\n");
    CHECK_U_INT(MESG_MESG_DCOM_ProcessSelection_En, expected_MESG_MESG_DCOM_ProcessSelection_En);
    CHECK_BOOLEAN(MESG_MESG_DCOM_EOLStopRequest_B, expected_MESG_MESG_DCOM_EOLStopRequest_B);
    CHECK_MEMORY("g_EOLActuationSetting_St", &g_EOLActuationSetting_St, &expected_g_EOLActuationSetting_St, sizeof(expected_g_EOLActuationSetting_St));
    CHECK_U_INT(g_RoutineControlState_En, expected_g_RoutineControlState_En);
    CHECK_U_INT(g_ForceClearDtcState_En, expected_g_ForceClearDtcState_En);
    CHECK_U_INT(g_ClearSingleDtcState_En, expected_g_ClearSingleDtcState_En);
    CHECK_U_INT(g_ForceClearDtc_EventMemLocation_u16, expected_g_ForceClearDtc_EventMemLocation_u16);
    CHECK_U_INT(g_ForceClearDtc_EventID_u16, expected_g_ForceClearDtc_EventID_u16);
    CHECK_U_INT(g_ForceClearDtc_DTCId_u16, expected_g_ForceClearDtc_DTCId_u16);
    CHECK_U_INT(g_ForceClearDtc_DTCCode_u16, expected_g_ForceClearDtc_DTCCode_u16);
    CHECK_BOOLEAN(g_ForceClearDtc_FailStatus_b, expected_g_ForceClearDtc_FailStatus_b);
    CHECK_U_CHAR(g_DemClearDTCReturnStatus_u8, expected_g_DemClearDTCReturnStatus_u8);
    CHECK_MEMORY("g_ValidDTCList_ForceClearDTC", g_ValidDTCList_ForceClearDTC, expected_g_ValidDTCList_ForceClearDTC, sizeof(expected_g_ValidDTCList_ForceClearDTC));
}

/* Prototypes for test functions */
void run_tests();
void test_RbAplCust_ESPSpecialDrive_Start(int);
void test_RbAplCust_ESPSpecialDrive_Start_1(int);
void test_RbAplCust_ESPSpecialDrive_Start_2(int);
void test_RbAplCust_ESPSpecialDrive_Start_3(int);
void test_RbAplCust_ESPSpecialDrive_Start_4(int);
void test_RbAplCust_ESPSpecialDrive_Start_5(int);
void test_RbAplCust_ESPSpecialDrive_Start_6(int);
void test_RbAplCust_ESPSpecialDrive_Start_7(int);
void test_RbAplCust_ESPSpecialDrive_Start_8(int);
void test_RbAplCust_ESPSpecialDrive_Start_9(int);
void test_RbAplCust_ESPSpecialDrive_Start_10(int);
void test_RbAplCust_ESPSpecialDrive_Start_11(int);
void test_RbAplCust_ESPSpecialDrive_Start_12(int);
void test_RbAplCust_ESPSpecialDrive_Start_13(int);
void test_RbAplCust_ESPSpecialDrive_Stop(int);
void test_RbAplCust_ESPSpecialDriveEntryCheck(int);
void test_RbAplCust_ESPSpecialDriveEntryCheck_1(int);
void test_RbAplCust_ESPSpecialDriveEntryCheck_2(int);
void test_RbAplCust_ForceClearDTCRun(int);
void test_RbAplCust_ForceClearDTCRun_1(int);
void test_RbAplCust_ForceClearDTCRun_2(int);
void test_RbAplCust_ForceClearDTCRun_3(int);
void test_RbAplCust_ForceClearDTCRun_4(int);
void test_RbAplCust_ForceClearDTCRun_5(int);
void test_RbAplCust_ForceClearDTCRun_6(int);
void test_RbAplCust_ForceClearDTCRun_7(int);
void test_RbAplCust_ForceClearDTCRun_8(int);
void test_RbAplCust_ForceClearDTCRun_9(int);
void test_RbAplCust_ForceClearDTCRun_10(int);
void test_RbAplCust_ForceClearDTCRun_11(int);
void test_RbAplCust_ForceClearDTCRun_12(int);
void test_RbAplCust_ForceClearDTCRun_13(int);
void test_RbAplCust_ForceClearDTCRun_14(int);
void test_RbAplCust_IsValidForceClearDTC(int);
void test_RbAplCust_IsValidForceClearDTC_1(int);

/*****************************************************************************/
/* Coverage Analysis                                                         */
/*****************************************************************************/
/* Coverage Rule Set: Report all coverage metrics */
static void rule_set(char* cppca_sut,
                     char* cppca_context)
{
#ifdef CANTPP_SUBSET_DEFERRED_ANALYSIS
    TEST_SCRIPT_WARNING("Coverage Rule Set ignored in deferred analysis mode\n");
#elif CANTPP_INSTRUMENTATION_DISABLED
    TEST_SCRIPT_WARNING("Instrumentation has been disabled\n");
#else
    REPORT_COVERAGE(cppca_entrypoint_cov|
                    cppca_callreturn_cov|
                    cppca_basicblock_cov|
                    cppca_statement_cov|
                    cppca_decision_cov|
                    cppca_relational_cov|
                    cppca_loop_cov|
                    cppca_condition_cov|
                    cppca_multcond_cov|
                    cppca_booleff_cov,
                    cppca_sut,
                    cppca_all_details|cppca_include_catch,
                    cppca_context);
#endif
}

/*****************************************************************************/
/* Program Entry Point                                                       */
/*****************************************************************************/
int main()
{
    CONFIGURE_COVERAGE("cov:boolcomb:yes");
    OPEN_LOG("atest_RBAPLCUST_RoutineControl_ESPSpecialDrive_Suzuki.ctr", false, 100);
    START_SCRIPT("RBAPLCUST_RoutineControl_ESPSpecialDrive_Suzuki", true);

    run_tests();

    return !END_SCRIPT(true);
}

/*****************************************************************************/
/* Test Control                                                              */
/*****************************************************************************/
/* run_tests() contains calls to the individual test cases, you can turn test*/
/* cases off by adding comments*/
void run_tests()
{
    test_RbAplCust_ESPSpecialDrive_Start(1);
    test_RbAplCust_ESPSpecialDrive_Start_1(1);
    test_RbAplCust_ESPSpecialDrive_Start_2(1);
    test_RbAplCust_ESPSpecialDrive_Start_3(1);
    test_RbAplCust_ESPSpecialDrive_Start_4(1);
    test_RbAplCust_ESPSpecialDrive_Start_5(1);
    test_RbAplCust_ESPSpecialDrive_Start_6(1);
    test_RbAplCust_ESPSpecialDrive_Start_7(1);
    test_RbAplCust_ESPSpecialDrive_Start_8(1);
    test_RbAplCust_ESPSpecialDrive_Start_9(1);
    test_RbAplCust_ESPSpecialDrive_Start_10(1);
    test_RbAplCust_ESPSpecialDrive_Start_11(1);
    test_RbAplCust_ESPSpecialDrive_Start_12(1);
    test_RbAplCust_ESPSpecialDrive_Start_13(1);
    test_RbAplCust_ESPSpecialDrive_Stop(1);
    test_RbAplCust_ESPSpecialDriveEntryCheck(1);
    test_RbAplCust_ESPSpecialDriveEntryCheck_1(1);
    test_RbAplCust_ESPSpecialDriveEntryCheck_2(1);
    test_RbAplCust_ForceClearDTCRun(1);
    test_RbAplCust_ForceClearDTCRun_1(1);
    test_RbAplCust_ForceClearDTCRun_2(1);
    test_RbAplCust_ForceClearDTCRun_3(1);
    test_RbAplCust_ForceClearDTCRun_4(1);
    test_RbAplCust_ForceClearDTCRun_5(1);
    test_RbAplCust_ForceClearDTCRun_6(1);
    test_RbAplCust_ForceClearDTCRun_7(1);
    test_RbAplCust_ForceClearDTCRun_8(1);
    test_RbAplCust_ForceClearDTCRun_9(1);
    test_RbAplCust_ForceClearDTCRun_10(1);
    test_RbAplCust_ForceClearDTCRun_11(1);
    test_RbAplCust_ForceClearDTCRun_12(1);
    test_RbAplCust_ForceClearDTCRun_13(1);
    test_RbAplCust_ForceClearDTCRun_14(1);
    test_RbAplCust_IsValidForceClearDTC(1);
    test_RbAplCust_IsValidForceClearDTC_1(1);

    rule_set("*", "*");
    EXPORT_COVERAGE("atest_RBAPLCUST_RoutineControl_ESPSpecialDrive_Suzuki.cov", cppca_export_replace);
}

/*****************************************************************************/
/* Test Cases                                                                */
/*****************************************************************************/

void test_RbAplCust_ESPSpecialDrive_Start(int doIt){
if (doIt) {
    /* Test case data declarations */
    uint8 dataIn1 = CANTATA_DEFAULT_VALUE;
    Dcm_OpStatusType OpStatus = CANTATA_DEFAULT_VALUE;
    Dcm_NegativeResponseCodeType * ErrorCode = &map_ErrorCode;
    Std_ReturnType expected_returnValue = CANTATA_DEFAULT_VALUE;
    Std_ReturnType returnValue;
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_returnValue = 0x0A;
    expected_g_EOLActuationSetting_St.ProcessTimer = 0x0000;
    expected_g_EOLActuationSetting_St.ActuationTimer = 0x0000;
    expected_g_EOLActuationSetting_St.ProcessTableID = 0x00;
    expected_g_EOLActuationSetting_St.ActuationTableID = 0x00;
    expected_g_EOLActuationSetting_St.AbsValveActuationRequest = 0x00;
    expected_g_EOLActuationSetting_St.OtherActuationRequest = 0x00;
    expected_g_RoutineControlState_En = 0;
    expected_g_ForceClearDtcState_En = 0;

    START_TEST("1:test_RbAplCust_ESPSpecialDrive_Start",
               "cover switch #297 at case #299: case C_Check_ReadyToStartRoutine_Init");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("{{RBSYS_EnterCommonLockSysfast#default}{RBSYS_ExitCommonLockSysfast#default}{RbAplCust_ReadyToStartRoutine#RBAPLCUST_RoutineStartPossible}{RbAplCust_EolProcessStop#default}{FUN_HMIIgOn2sCheck_B#default}{Dem_DisableDTCSetting#default}{RbAplCust_ForceClearDTCRun#default}{RbAplCust_EraseFreezeFrameDataInfo#default}}");
            /* Call SUT */

            returnValue = RbAplCust_ESPSpecialDrive_Start(dataIn1, OpStatus, ErrorCode);

            /* Test case checks */
            CHECK_U_CHAR(returnValue, expected_returnValue);
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_RbAplCust_ESPSpecialDrive_Start_1(int doIt){
if (doIt) {
    /* Test case data declarations */
    uint8 dataIn1 = CANTATA_DEFAULT_VALUE;
    Dcm_OpStatusType OpStatus = CANTATA_DEFAULT_VALUE;
    Dcm_NegativeResponseCodeType * ErrorCode = &map_ErrorCode;
    Std_ReturnType expected_returnValue = CANTATA_DEFAULT_VALUE;
    Std_ReturnType returnValue;
    /* Set global data */
    initialise_global_data();
    g_RoutineControlState_En = C_RoutineControl_Init;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_returnValue = 0x0A;
    expected_MESG_MESG_DCOM_ProcessSelection_En = 5;

    START_TEST("2:test_RbAplCust_ESPSpecialDrive_Start_1",
               "cover switch #297 at case #356: case C_Check_ReadyToStartRoutine_Done:");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("{{RBSYS_EnterCommonLockSysfast#default}{RBSYS_ExitCommonLockSysfast#default}{RbAplCust_ReadyToStartRoutine#RBAPLCUST_RoutineStartPossible}{RbAplCust_EolProcessStop#default}{FUN_HMIIgOn2sCheck_B#default}{Dem_DisableDTCSetting#default}{RbAplCust_ForceClearDTCRun#default}{RbAplCust_EraseFreezeFrameDataInfo#default}}");
            /* Call SUT */

            returnValue = RbAplCust_ESPSpecialDrive_Start(dataIn1, OpStatus, ErrorCode);

            /* Test case checks */
            CHECK_U_CHAR(returnValue, expected_returnValue);
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_RbAplCust_ESPSpecialDrive_Start_2(int doIt){
if (doIt) {
    /* Test case data declarations */
    uint8 dataIn1 = CANTATA_DEFAULT_VALUE;
    Dcm_OpStatusType OpStatus = CANTATA_DEFAULT_VALUE;
    Dcm_NegativeResponseCodeType * ErrorCode = &map_ErrorCode;
    Std_ReturnType expected_returnValue = CANTATA_DEFAULT_VALUE;
    Std_ReturnType returnValue;
    /* Set global data */
    initialise_global_data();
    g_RoutineControlState_En = C_RoutineControl_Init;
    g_ForceClearDtcState_En = C_ForceClearDtc_Starts;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_returnValue = 0x0A;
    expected_MESG_MESG_DCOM_ProcessSelection_En = 5;
    expected_g_RoutineControlState_En = 4;

    START_TEST("3:test_RbAplCust_ESPSpecialDrive_Start_2",
               "cover switch #297 at case #356: case C_Check_ReadyToStartRoutine_Done:");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("{{RBSYS_EnterCommonLockSysfast#default}{RBSYS_ExitCommonLockSysfast#default}{RbAplCust_ReadyToStartRoutine#RBAPLCUST_RoutineStartPossible}{RbAplCust_EolProcessStop#default}{FUN_HMIIgOn2sCheck_B#FALSE}{Dem_DisableDTCSetting#default}{RbAplCust_ForceClearDTCRun#default}{RbAplCust_EraseFreezeFrameDataInfo#default}}");
            /* Call SUT */

            returnValue = RbAplCust_ESPSpecialDrive_Start(dataIn1, OpStatus, ErrorCode);

            /* Test case checks */
            CHECK_U_CHAR(returnValue, expected_returnValue);
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_RbAplCust_ESPSpecialDrive_Start_3(int doIt){
if (doIt) {
    /* Test case data declarations */
    uint8 dataIn1 = CANTATA_DEFAULT_VALUE;
    Dcm_OpStatusType OpStatus = CANTATA_DEFAULT_VALUE;
    Dcm_NegativeResponseCodeType * ErrorCode = &map_ErrorCode;
    Std_ReturnType expected_returnValue = CANTATA_DEFAULT_VALUE;
    Std_ReturnType returnValue;
    /* Set global data */
    initialise_global_data();
    g_RoutineControlState_En = C_RoutineControl_Init;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_returnValue = 0x0A;

    START_TEST("4:test_RbAplCust_ESPSpecialDrive_Start_3",
               "cover switch #297 at case #356: false #364: if(!FUN_HMIIgOn2sCheck_B())");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("{{RBSYS_EnterCommonLockSysfast#default}{RBSYS_ExitCommonLockSysfast#default}{RbAplCust_ReadyToStartRoutine#RBAPLCUST_RoutineStartPossible}{RbAplCust_EolProcessStop#default}{FUN_HMIIgOn2sCheck_B#TRUE}{Dem_DisableDTCSetting#default}{RbAplCust_ForceClearDTCRun#default}{RbAplCust_EraseFreezeFrameDataInfo#default}}");
            /* Call SUT */

            returnValue = RbAplCust_ESPSpecialDrive_Start(dataIn1, OpStatus, ErrorCode);

            /* Test case checks */
            CHECK_U_CHAR(returnValue, expected_returnValue);
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_RbAplCust_ESPSpecialDrive_Start_4(int doIt){
if (doIt) {
    /* Test case data declarations */
    uint8 dataIn1 = CANTATA_DEFAULT_VALUE;
    Dcm_OpStatusType OpStatus = CANTATA_DEFAULT_VALUE;
    Dcm_NegativeResponseCodeType * ErrorCode = &map_ErrorCode;
    Std_ReturnType expected_returnValue = CANTATA_DEFAULT_VALUE;
    Std_ReturnType returnValue;
    /* Set global data */
    initialise_global_data();
    g_RoutineControlState_En = C_RoutineControl_Init;
    g_ForceClearDtcState_En = C_ForceClearDtc_Running;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_returnValue = 0x0A;
    expected_MESG_MESG_DCOM_ProcessSelection_En = 5;

    START_TEST("5:test_RbAplCust_ESPSpecialDrive_Start_4",
               "cover switch #297 at case #356: case C_Check_ReadyToStartRoutine_Done:");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("{{RBSYS_EnterCommonLockSysfast#default}{RBSYS_ExitCommonLockSysfast#default}{RbAplCust_ReadyToStartRoutine#RBAPLCUST_RoutineStartPossible}{RbAplCust_EolProcessStop#default}{FUN_HMIIgOn2sCheck_B#FALSE}{Dem_DisableDTCSetting#default}{RbAplCust_ForceClearDTCRun#default}{RbAplCust_EraseFreezeFrameDataInfo#default}}");
            /* Call SUT */

            returnValue = RbAplCust_ESPSpecialDrive_Start(dataIn1, OpStatus, ErrorCode);

            /* Test case checks */
            CHECK_U_CHAR(returnValue, expected_returnValue);
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_RbAplCust_ESPSpecialDrive_Start_5(int doIt){
if (doIt) {
    /* Test case data declarations */
    uint8 dataIn1 = CANTATA_DEFAULT_VALUE;
    Dcm_OpStatusType OpStatus = CANTATA_DEFAULT_VALUE;
    Dcm_NegativeResponseCodeType * ErrorCode = &map_ErrorCode;
    Std_ReturnType expected_returnValue = CANTATA_DEFAULT_VALUE;
    Std_ReturnType returnValue;
    /* Set global data */
    initialise_global_data();
    g_RoutineControlState_En = C_RoutineControl_Running;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_returnValue = 0x0A;

    START_TEST("6:test_RbAplCust_ESPSpecialDrive_Start_5",
               "cover switch #297 at case #396: case C_RoutineControl_Running: switch case #400: case #403: case C_ForceClearDtc_Starts");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("{{RBSYS_EnterCommonLockSysfast#default}{RBSYS_ExitCommonLockSysfast#default}{RbAplCust_ReadyToStartRoutine#default}{RbAplCust_EolProcessStop#default}{FUN_HMIIgOn2sCheck_B#default}{Dem_DisableDTCSetting#default}{RbAplCust_ForceClearDTCRun#C_ForceClearDtc_Starts}{RbAplCust_EraseFreezeFrameDataInfo#default}}");
            /* Call SUT */

            returnValue = RbAplCust_ESPSpecialDrive_Start(dataIn1, OpStatus, ErrorCode);

            /* Test case checks */
            CHECK_U_CHAR(returnValue, expected_returnValue);
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_RbAplCust_ESPSpecialDrive_Start_6(int doIt){
if (doIt) {
    /* Test case data declarations */
    uint8 dataIn1 = CANTATA_DEFAULT_VALUE;
    Dcm_OpStatusType OpStatus = CANTATA_DEFAULT_VALUE;
    Dcm_NegativeResponseCodeType * ErrorCode = &map_ErrorCode;
    Std_ReturnType expected_returnValue = CANTATA_DEFAULT_VALUE;
    Std_ReturnType returnValue;
    /* Set global data */
    initialise_global_data();
    g_RoutineControlState_En = C_RoutineControl_Running;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_returnValue = 0x0A;

    START_TEST("7:test_RbAplCust_ESPSpecialDrive_Start_6",
               "cover switch #297 at case #396: case C_RoutineControl_Running: switch case #400: case #411: C_ForceClearDtc_Running");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("{{RBSYS_EnterCommonLockSysfast#default}{RBSYS_ExitCommonLockSysfast#default}{RbAplCust_ReadyToStartRoutine#default}{RbAplCust_EolProcessStop#default}{FUN_HMIIgOn2sCheck_B#default}{Dem_DisableDTCSetting#default}{RbAplCust_ForceClearDTCRun#C_ForceClearDtc_Running}{RbAplCust_EraseFreezeFrameDataInfo#default}}");
            /* Call SUT */

            returnValue = RbAplCust_ESPSpecialDrive_Start(dataIn1, OpStatus, ErrorCode);

            /* Test case checks */
            CHECK_U_CHAR(returnValue, expected_returnValue);
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_RbAplCust_ESPSpecialDrive_Start_7(int doIt){
if (doIt) {
    /* Test case data declarations */
    uint8 dataIn1 = CANTATA_DEFAULT_VALUE;
    Dcm_OpStatusType OpStatus = CANTATA_DEFAULT_VALUE;
    Dcm_NegativeResponseCodeType * ErrorCode = &map_ErrorCode;
    Std_ReturnType expected_returnValue = CANTATA_DEFAULT_VALUE;
    Std_ReturnType returnValue;
    /* Set global data */
    initialise_global_data();
    g_RoutineControlState_En = C_RoutineControl_Running;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_returnValue = 0x0A;
    expected_g_RoutineControlState_En = 5;

    START_TEST("8:test_RbAplCust_ESPSpecialDrive_Start_7",
               "cover switch #297 at case #396: case C_RoutineControl_Running: switch case #400: case C_ForceClearDtc_Finished");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("{{RBSYS_EnterCommonLockSysfast#default}{RBSYS_ExitCommonLockSysfast#default}{RbAplCust_ReadyToStartRoutine#default}{RbAplCust_EolProcessStop#default}{FUN_HMIIgOn2sCheck_B#default}{Dem_DisableDTCSetting#default}{RbAplCust_ForceClearDTCRun#C_ForceClearDtc_Finished}{RbAplCust_EraseFreezeFrameDataInfo#default}}");
            /* Call SUT */

            returnValue = RbAplCust_ESPSpecialDrive_Start(dataIn1, OpStatus, ErrorCode);

            /* Test case checks */
            CHECK_U_CHAR(returnValue, expected_returnValue);
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_RbAplCust_ESPSpecialDrive_Start_8(int doIt){
if (doIt) {
    /* Test case data declarations */
    uint8 dataIn1 = CANTATA_DEFAULT_VALUE;
    Dcm_OpStatusType OpStatus = CANTATA_DEFAULT_VALUE;
    Dcm_NegativeResponseCodeType * ErrorCode = &map_ErrorCode;
    Std_ReturnType expected_returnValue = CANTATA_DEFAULT_VALUE;
    Std_ReturnType returnValue;
    /* Set global data */
    initialise_global_data();
    g_RoutineControlState_En = C_RoutineControl_Running;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_returnValue = 0x0A;
    expected_g_RoutineControlState_En = 6;

    START_TEST("9:test_RbAplCust_ESPSpecialDrive_Start_8",
               "cover switch #297 at case #396: case C_RoutineControl_Running: switch case #400: case C_ForceClearDtc_Failed");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("{{RBSYS_EnterCommonLockSysfast#default}{RBSYS_ExitCommonLockSysfast#default}{RbAplCust_ReadyToStartRoutine#default}{RbAplCust_EolProcessStop#default}{FUN_HMIIgOn2sCheck_B#default}{Dem_DisableDTCSetting#default}{RbAplCust_ForceClearDTCRun#C_ForceClearDtc_Failed}{RbAplCust_EraseFreezeFrameDataInfo#default}}");
            /* Call SUT */

            returnValue = RbAplCust_ESPSpecialDrive_Start(dataIn1, OpStatus, ErrorCode);

            /* Test case checks */
            CHECK_U_CHAR(returnValue, expected_returnValue);
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_RbAplCust_ESPSpecialDrive_Start_9(int doIt){
if (doIt) {
    /* Test case data declarations */
    uint8 dataIn1 = CANTATA_DEFAULT_VALUE;
    Dcm_OpStatusType OpStatus = CANTATA_DEFAULT_VALUE;
    Dcm_NegativeResponseCodeType * ErrorCode = &map_ErrorCode;
    Std_ReturnType expected_returnValue = CANTATA_DEFAULT_VALUE;
    Std_ReturnType returnValue;
    /* Set global data */
    initialise_global_data();
    g_RoutineControlState_En = C_RoutineControl_Finished;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_MESG_MESG_DCOM_ProcessSelection_En = 0;
    expected_g_RoutineControlState_En = 0;
    expected_g_ForceClearDtcState_En = 0;

    START_TEST("10:test_RbAplCust_ESPSpecialDrive_Start_9",
               "cover switch #297 at case #396: case C_RoutineControl_Running: switch case #400: case C_RoutineControl_Finished");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("{{RBSYS_EnterCommonLockSysfast#default}{RBSYS_ExitCommonLockSysfast#default}{RbAplCust_ReadyToStartRoutine#default}{RbAplCust_EolProcessStop#default}{FUN_HMIIgOn2sCheck_B#default}{Dem_DisableDTCSetting#default}{RbAplCust_ForceClearDTCRun#C_ForceClearDtc_Failed}{RbAplCust_EraseFreezeFrameDataInfo#default}}");
            /* Call SUT */

            returnValue = RbAplCust_ESPSpecialDrive_Start(dataIn1, OpStatus, ErrorCode);

            /* Test case checks */
            CHECK_U_CHAR(returnValue, expected_returnValue);
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_RbAplCust_ESPSpecialDrive_Start_10(int doIt){
if (doIt) {
    /* Test case data declarations */
    uint8 dataIn1 = CANTATA_DEFAULT_VALUE;
    Dcm_OpStatusType OpStatus = CANTATA_DEFAULT_VALUE;
    Dcm_NegativeResponseCodeType * ErrorCode = &map_ErrorCode;
    Std_ReturnType expected_returnValue = CANTATA_DEFAULT_VALUE;
    Std_ReturnType returnValue;
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_returnValue = 0x0A;

    START_TEST("11:test_RbAplCust_ESPSpecialDrive_Start_10",
               "reset ReadyToStartRoutine_State_EN to C_Check_ReadyToStartRoutine_Done: cover switch #297 at case #299: case C_Check_ReadyToStartRoutine_Init");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("{{RBSYS_EnterCommonLockSysfast#default}{RBSYS_ExitCommonLockSysfast#default}{RbAplCust_ReadyToStartRoutine#RBAPLCUST_RoutineSameRunning}{RbAplCust_EolProcessStop#default}{FUN_HMIIgOn2sCheck_B#default}{Dem_DisableDTCSetting#default}{RbAplCust_ForceClearDTCRun#default}{RbAplCust_EraseFreezeFrameDataInfo#default}}");
            /* Call SUT */

            returnValue = RbAplCust_ESPSpecialDrive_Start(dataIn1, OpStatus, ErrorCode);

            /* Test case checks */
            CHECK_U_CHAR(returnValue, expected_returnValue);
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_RbAplCust_ESPSpecialDrive_Start_11(int doIt){
if (doIt) {
    /* Test case data declarations */
    uint8 dataIn1 = CANTATA_DEFAULT_VALUE;
    Dcm_OpStatusType OpStatus = CANTATA_DEFAULT_VALUE;
    Dcm_NegativeResponseCodeType * ErrorCode = &map_ErrorCode;
    Std_ReturnType expected_returnValue = CANTATA_DEFAULT_VALUE;
    Std_ReturnType returnValue;
    /* Set global data */
    initialise_global_data();
    g_RoutineControlState_En = C_RoutineControl_Failed;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_returnValue = 0x01;
    expected_MESG_MESG_DCOM_ProcessSelection_En = 0;
    expected_g_RoutineControlState_En = 0;
    expected_g_ForceClearDtcState_En = 0;

    START_TEST("12:test_RbAplCust_ESPSpecialDrive_Start_11",
               "cover switch #297 at case #396: case C_RoutineControl_Running: switch case #400: case C_RoutineControl_Failed");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("{{RBSYS_EnterCommonLockSysfast#default}{RBSYS_ExitCommonLockSysfast#default}{RbAplCust_ReadyToStartRoutine#default}{RbAplCust_EolProcessStop#default}{FUN_HMIIgOn2sCheck_B#default}{Dem_DisableDTCSetting#default}{RbAplCust_ForceClearDTCRun#C_ForceClearDtc_Failed}{RbAplCust_EraseFreezeFrameDataInfo#default}}");
            /* Call SUT */

            returnValue = RbAplCust_ESPSpecialDrive_Start(dataIn1, OpStatus, ErrorCode);

            /* Test case checks */
            CHECK_U_CHAR(returnValue, expected_returnValue);
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_RbAplCust_ESPSpecialDrive_Start_12(int doIt){
if (doIt) {
    /* Test case data declarations */
    uint8 dataIn1 = CANTATA_DEFAULT_VALUE;
    Dcm_OpStatusType OpStatus = CANTATA_DEFAULT_VALUE;
    Dcm_NegativeResponseCodeType * ErrorCode = &map_ErrorCode;
    Std_ReturnType expected_returnValue = CANTATA_DEFAULT_VALUE;
    Std_ReturnType returnValue;
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_returnValue = 0x0A;
    expected_g_EOLActuationSetting_St.ProcessTimer = 0x0000;
    expected_g_EOLActuationSetting_St.ActuationTimer = 0x0000;
    expected_g_EOLActuationSetting_St.ProcessTableID = 0x00;
    expected_g_EOLActuationSetting_St.ActuationTableID = 0x00;
    expected_g_EOLActuationSetting_St.AbsValveActuationRequest = 0x00;
    expected_g_EOLActuationSetting_St.OtherActuationRequest = 0x00;
    expected_g_RoutineControlState_En = 0;
    expected_g_ForceClearDtcState_En = 0;

    START_TEST("13:test_RbAplCust_ESPSpecialDrive_Start_12",
               "reset ReadyToStartRoutine_State_EN to C_Check_ReadyToStartRoutine_Done: cover switch #297 at case #299: case C_Check_ReadyToStartRoutine_Init");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("{{RBSYS_EnterCommonLockSysfast#default}{RBSYS_ExitCommonLockSysfast#default}{RbAplCust_ReadyToStartRoutine#RBAPLCUST_RoutineOtherRunning}{RbAplCust_EolProcessStop#default}{FUN_HMIIgOn2sCheck_B#default}{Dem_DisableDTCSetting#default}{RbAplCust_ForceClearDTCRun#default}{RbAplCust_EraseFreezeFrameDataInfo#default}}");
            /* Call SUT */

            returnValue = RbAplCust_ESPSpecialDrive_Start(dataIn1, OpStatus, ErrorCode);

            /* Test case checks */
            CHECK_U_CHAR(returnValue, expected_returnValue);
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_RbAplCust_ESPSpecialDrive_Start_13(int doIt){
if (doIt) {
    /* Test case data declarations */
    uint8 dataIn1 = CANTATA_DEFAULT_VALUE;
    Dcm_OpStatusType OpStatus = CANTATA_DEFAULT_VALUE;
    Dcm_NegativeResponseCodeType * ErrorCode = &map_ErrorCode;
    Std_ReturnType expected_returnValue = CANTATA_DEFAULT_VALUE;
    Std_ReturnType returnValue;
    /* Set global data */
    initialise_global_data();
    g_RoutineControlState_En = C_RoutineControl_ConditionNotCorrect;
    /* Set expected values for global data checks */
    initialise_expected_global_data();

    START_TEST("14:test_RbAplCust_ESPSpecialDrive_Start_13",
               "cover switch #297 at case #396: case C_RoutineControl_Running: switch case #400: case default");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("{{RBSYS_EnterCommonLockSysfast#default}{RBSYS_ExitCommonLockSysfast#default}{RbAplCust_ReadyToStartRoutine#default}{RbAplCust_EolProcessStop#default}{FUN_HMIIgOn2sCheck_B#default}{Dem_DisableDTCSetting#default}{RbAplCust_ForceClearDTCRun#C_ForceClearDtc_Failed}{RbAplCust_EraseFreezeFrameDataInfo#default}}");
            /* Call SUT */

            returnValue = RbAplCust_ESPSpecialDrive_Start(dataIn1, OpStatus, ErrorCode);

            /* Test case checks */
            CHECK_U_CHAR(returnValue, expected_returnValue);
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_RbAplCust_ESPSpecialDrive_Stop(int doIt){
if (doIt) {
    /* Test case data declarations */
    uint8 dataIn1 = CANTATA_DEFAULT_VALUE;
    Dcm_OpStatusType OpStatus = CANTATA_DEFAULT_VALUE;
    Dcm_NegativeResponseCodeType * ErrorCode = &map_ErrorCode;
    Std_ReturnType expected_returnValue = CANTATA_DEFAULT_VALUE;
    Std_ReturnType returnValue;
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();

    START_TEST("15:test_RbAplCust_ESPSpecialDrive_Stop",
               "default case");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            returnValue = RbAplCust_ESPSpecialDrive_Stop(dataIn1, OpStatus, ErrorCode);

            /* Test case checks */
            CHECK_U_CHAR(returnValue, expected_returnValue);
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_RbAplCust_ESPSpecialDriveEntryCheck(int doIt){
if (doIt) {
    /* Test case data declarations */
    Std_ReturnType expected_returnValue = CANTATA_DEFAULT_VALUE;
    Std_ReturnType returnValue;
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();

    START_TEST("16:test_RbAplCust_ESPSpecialDriveEntryCheck",
               "cover true #564: if(E_OK == RbAplCust_CheckAllWheelSpeed(RBAPLCUST_ROUTINECONTROL_WHEELSPEED_0KMPH))");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("{{RbAplCust_CheckRoutineOperationVoltage#E_OK}{RbAplCust_CheckAllWheelSpeed#E_OK}}");

            /* Call SUT */
            returnValue = RbAplCust_ESPSpecialDriveEntryCheck();

            /* Test case checks */
            CHECK_U_CHAR(returnValue, expected_returnValue);
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_RbAplCust_ESPSpecialDriveEntryCheck_1(int doIt){
if (doIt) {
    /* Test case data declarations */
    Std_ReturnType expected_returnValue = CANTATA_DEFAULT_VALUE;
    Std_ReturnType returnValue;
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_returnValue = 0x01;

    START_TEST("17:test_RbAplCust_ESPSpecialDriveEntryCheck_1",
               "cover false #564: if(E_OK == RbAplCust_CheckAllWheelSpeed(RBAPLCUST_ROUTINECONTROL_WHEELSPEED_0KMPH))");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("{{RbAplCust_CheckRoutineOperationVoltage#E_OK}{RbAplCust_CheckAllWheelSpeed#E_NOT_OK}}");

            /* Call SUT */
            returnValue = RbAplCust_ESPSpecialDriveEntryCheck();

            /* Test case checks */
            CHECK_U_CHAR(returnValue, expected_returnValue);
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_RbAplCust_ESPSpecialDriveEntryCheck_2(int doIt){
if (doIt) {
    /* Test case data declarations */
    Std_ReturnType expected_returnValue = CANTATA_DEFAULT_VALUE;
    Std_ReturnType returnValue;
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_returnValue = 0x01;

    START_TEST("18:test_RbAplCust_ESPSpecialDriveEntryCheck_2",
               "cover false #561: if(E_OK == RbAplCust_CheckRoutineOperationVoltage())");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("{{RbAplCust_CheckRoutineOperationVoltage#E_NOT_OK}{RbAplCust_CheckAllWheelSpeed#E_NOT_OK}}");

            /* Call SUT */
            returnValue = RbAplCust_ESPSpecialDriveEntryCheck();

            /* Test case checks */
            CHECK_U_CHAR(returnValue, expected_returnValue);
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_RbAplCust_ForceClearDTCRun(int doIt){
if (doIt) {
    /* Test case data declarations */
    ForceClearAllDTC_State_EN expected_returnValue = CANTATA_DEFAULT_VALUE;
    ForceClearAllDTC_State_EN returnValue;
    /* Set global data */
    initialise_global_data();
    g_ForceClearDtcState_En = C_ForceClearDtc_Starts;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_returnValue = 1;
    expected_g_ForceClearDtcState_En = 1;
    expected_g_ClearSingleDtcState_En = 0;

    START_TEST("19:test_RbAplCust_ForceClearDTCRun",
               "cover switch case #600: case C_ForceClearDtc_Starts");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("{{Dem_EvMemEventMemoryLocIteratorNew#default}{Dem_EvMemEventMemoryLocIteratorIsValid#default}{Dem_EvMemGetEventMemEventId#default}{Dem_DtcIdFromEventId#default}{Dem_DtcGetCode#default}{Dem_isDtcIdValid#default}{RbAplCust_IsValidForceClearDTC#default}{Dem_EvMemEventMemoryLocIteratorNext#default}{Dem_ClearDTC#default}}");

            /* Call SUT */
            returnValue = RbAplCust_ForceClearDTCRun();

            /* Test case checks */
            CHECK_U_INT(returnValue, expected_returnValue);
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_RbAplCust_ForceClearDTCRun_1(int doIt){
if (doIt) {
    /* Test case data declarations */
    ForceClearAllDTC_State_EN expected_returnValue = CANTATA_DEFAULT_VALUE;
    ForceClearAllDTC_State_EN returnValue;
    /* Set global data */
    initialise_global_data();
    g_ForceClearDtcState_En = C_ForceClearDtc_Running;
    g_ClearSingleDtcState_En = C_ClearSingleDtc_Init;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_returnValue = 1;
    expected_g_ClearSingleDtcState_En = 1;

    START_TEST("20:test_RbAplCust_ForceClearDTCRun_1",
               "cover switch case #600: case C_ForceClearDtc_Running");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("{{Dem_EvMemEventMemoryLocIteratorNew#default}{Dem_EvMemEventMemoryLocIteratorIsValid#default}{Dem_EvMemGetEventMemEventId#default}{Dem_DtcIdFromEventId#default}{Dem_DtcGetCode#default}{Dem_isDtcIdValid#default}{RbAplCust_IsValidForceClearDTC#default}{Dem_EvMemEventMemoryLocIteratorNext#default}{Dem_ClearDTC#default}}");

            /* Call SUT */
            returnValue = RbAplCust_ForceClearDTCRun();

            /* Test case checks */
            CHECK_U_INT(returnValue, expected_returnValue);
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_RbAplCust_ForceClearDTCRun_2(int doIt){
if (doIt) {
    /* Test case data declarations */
    ForceClearAllDTC_State_EN expected_returnValue = CANTATA_DEFAULT_VALUE;
    ForceClearAllDTC_State_EN returnValue;
    /* Set global data */
    initialise_global_data();
    g_ForceClearDtcState_En = C_ForceClearDtc_Running;
    g_ClearSingleDtcState_En = C_ClearSingleDtc_ValidityCheck;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_returnValue = 1;
    expected_g_ClearSingleDtcState_En = 2;
    expected_g_ForceClearDtc_EventID_u16 = 0;
    expected_g_ForceClearDtc_DTCId_u16 = 0;
    expected_g_ForceClearDtc_DTCCode_u16 = 0;

    START_TEST("21:test_RbAplCust_ForceClearDTCRun_2",
               "cover switch case #600: case C_ForceClearDtc_Running: switch #633: case C_ClearSingleDtc_ValidityCheck");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("{{Dem_EvMemEventMemoryLocIteratorNew#default}{Dem_EvMemEventMemoryLocIteratorIsValid#TRUE}{Dem_EvMemGetEventMemEventId#default}{Dem_DtcIdFromEventId#default}{Dem_DtcGetCode#default}{Dem_isDtcIdValid#TRUE}{RbAplCust_IsValidForceClearDTC#E_OK}{Dem_EvMemEventMemoryLocIteratorNext#default}{Dem_ClearDTC#default}}");

            /* Call SUT */
            returnValue = RbAplCust_ForceClearDTCRun();

            /* Test case checks */
            CHECK_U_INT(returnValue, expected_returnValue);
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_RbAplCust_ForceClearDTCRun_3(int doIt){
if (doIt) {
    /* Test case data declarations */
    ForceClearAllDTC_State_EN expected_returnValue = CANTATA_DEFAULT_VALUE;
    ForceClearAllDTC_State_EN returnValue;
    /* Set global data */
    initialise_global_data();
    g_ForceClearDtcState_En = C_ForceClearDtc_Running;
    g_ClearSingleDtcState_En = C_ClearSingleDtc_ValidityCheck;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_returnValue = 1;
    expected_g_ForceClearDtc_EventID_u16 = 0;
    expected_g_ForceClearDtc_DTCId_u16 = 0;
    expected_g_ForceClearDtc_DTCCode_u16 = 0;

    START_TEST("22:test_RbAplCust_ForceClearDTCRun_3",
               "cover switch case #600: case C_ForceClearDtc_Running: switch #633: case C_ClearSingleDtc_ValidityCheck: false condition #648: if(Dem_isDtcIdValid(g_ForceClearDtc_DTCId_u16) && (E_OK==RbAplCust_IsValidForceClearDTC(g_ForceClearDtc_DTCCode_u16)))");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("{{Dem_EvMemEventMemoryLocIteratorNew#default}{Dem_EvMemEventMemoryLocIteratorIsValid#TRUE}{Dem_EvMemGetEventMemEventId#default}{Dem_DtcIdFromEventId#default}{Dem_DtcGetCode#default}{Dem_isDtcIdValid#FALSE}{RbAplCust_IsValidForceClearDTC#E_OK}{Dem_EvMemEventMemoryLocIteratorNext#default}{Dem_ClearDTC#default}}");

            /* Call SUT */
            returnValue = RbAplCust_ForceClearDTCRun();

            /* Test case checks */
            CHECK_U_INT(returnValue, expected_returnValue);
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_RbAplCust_ForceClearDTCRun_4(int doIt){
if (doIt) {
    /* Test case data declarations */
    ForceClearAllDTC_State_EN expected_returnValue = CANTATA_DEFAULT_VALUE;
    ForceClearAllDTC_State_EN returnValue;
    /* Set global data */
    initialise_global_data();
    g_ForceClearDtcState_En = C_ForceClearDtc_Running;
    g_ClearSingleDtcState_En = C_ClearSingleDtc_ValidityCheck;
    g_ForceClearDtc_FailStatus_b = TRUE;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_returnValue = 1;
    expected_g_ClearSingleDtcState_En = 4;

    START_TEST("23:test_RbAplCust_ForceClearDTCRun_4",
               "cover switch case #600: case C_ForceClearDtc_Running: switch #633: case C_ClearSingleDtc_ValidityCheck: false condition #636: if( Dem_EvMemEventMemoryLocIteratorIsValid(&g_ForceClearDtc_EventMemLocation_u16, DEM_CFG_EVMEM_MEMID_PRIMARY))");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("{{Dem_EvMemEventMemoryLocIteratorNew#default}{Dem_EvMemEventMemoryLocIteratorIsValid#FALSE}{Dem_EvMemGetEventMemEventId#default}{Dem_DtcIdFromEventId#default}{Dem_DtcGetCode#default}{Dem_isDtcIdValid#default}{RbAplCust_IsValidForceClearDTC#default}{Dem_EvMemEventMemoryLocIteratorNext#default}{Dem_ClearDTC#default}}");

            /* Call SUT */
            returnValue = RbAplCust_ForceClearDTCRun();

            /* Test case checks */
            CHECK_U_INT(returnValue, expected_returnValue);
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_RbAplCust_ForceClearDTCRun_5(int doIt){
if (doIt) {
    /* Test case data declarations */
    ForceClearAllDTC_State_EN expected_returnValue = CANTATA_DEFAULT_VALUE;
    ForceClearAllDTC_State_EN returnValue;
    /* Set global data */
    initialise_global_data();
    g_ForceClearDtcState_En = C_ForceClearDtc_Running;
    g_ClearSingleDtcState_En = C_ClearSingleDtc_ValidityCheck;
    g_ForceClearDtc_FailStatus_b = FALSE;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_returnValue = 1;
    expected_g_ClearSingleDtcState_En = 3;

    START_TEST("24:test_RbAplCust_ForceClearDTCRun_5",
               "cover switch case #600: case C_ForceClearDtc_Running: switch #633: case C_ClearSingleDtc_ValidityCheck: false condition #665: if(TRUE == g_ForceClearDtc_FailStatus_b)");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("{{Dem_EvMemEventMemoryLocIteratorNew#default}{Dem_EvMemEventMemoryLocIteratorIsValid#FALSE}{Dem_EvMemGetEventMemEventId#default}{Dem_DtcIdFromEventId#default}{Dem_DtcGetCode#default}{Dem_isDtcIdValid#default}{RbAplCust_IsValidForceClearDTC#default}{Dem_EvMemEventMemoryLocIteratorNext#default}{Dem_ClearDTC#default}}");

            /* Call SUT */
            returnValue = RbAplCust_ForceClearDTCRun();

            /* Test case checks */
            CHECK_U_INT(returnValue, expected_returnValue);
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_RbAplCust_ForceClearDTCRun_6(int doIt){
if (doIt) {
    /* Test case data declarations */
    ForceClearAllDTC_State_EN expected_returnValue = CANTATA_DEFAULT_VALUE;
    ForceClearAllDTC_State_EN returnValue;
    /* Set global data */
    initialise_global_data();
    g_ForceClearDtcState_En = C_ForceClearDtc_Running;
    g_ClearSingleDtcState_En = C_ClearSingleDtc_Running;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_returnValue = 1;
    expected_g_ClearSingleDtcState_En = 1;
    expected_g_DemClearDTCReturnStatus_u8 = 0x00;

    START_TEST("25:test_RbAplCust_ForceClearDTCRun_2",
               "cover switch case #600: case C_ForceClearDtc_Running: switch #690: case DEM_CLEAR_OK");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("{{Dem_EvMemEventMemoryLocIteratorNew#default}{Dem_EvMemEventMemoryLocIteratorIsValid#default}{Dem_EvMemGetEventMemEventId#default}{Dem_DtcIdFromEventId#default}{Dem_DtcGetCode#default}{Dem_isDtcIdValid#default}{RbAplCust_IsValidForceClearDTC#default}{Dem_EvMemEventMemoryLocIteratorNext#default}{Dem_ClearDTC#DEM_CLEAR_OK}}");

            /* Call SUT */
            returnValue = RbAplCust_ForceClearDTCRun();

            /* Test case checks */
            CHECK_U_INT(returnValue, expected_returnValue);
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_RbAplCust_ForceClearDTCRun_7(int doIt){
if (doIt) {
    /* Test case data declarations */
    ForceClearAllDTC_State_EN expected_returnValue = CANTATA_DEFAULT_VALUE;
    ForceClearAllDTC_State_EN returnValue;
    /* Set global data */
    initialise_global_data();
    g_ForceClearDtcState_En = C_ForceClearDtc_Running;
    g_ClearSingleDtcState_En = C_ClearSingleDtc_Running;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_returnValue = 1;
    expected_g_DemClearDTCReturnStatus_u8 = 0x04;

    START_TEST("26:test_RbAplCust_ForceClearDTCRun_3",
               "cover switch case #600: case C_ForceClearDtc_Running: switch #690: case DEM_CLEAR_PENDING");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("{{Dem_EvMemEventMemoryLocIteratorNew#default}{Dem_EvMemEventMemoryLocIteratorIsValid#default}{Dem_EvMemGetEventMemEventId#default}{Dem_DtcIdFromEventId#default}{Dem_DtcGetCode#default}{Dem_isDtcIdValid#default}{RbAplCust_IsValidForceClearDTC#default}{Dem_EvMemEventMemoryLocIteratorNext#default}{Dem_ClearDTC#DEM_CLEAR_PENDING}}");

            /* Call SUT */
            returnValue = RbAplCust_ForceClearDTCRun();

            /* Test case checks */
            CHECK_U_INT(returnValue, expected_returnValue);
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_RbAplCust_ForceClearDTCRun_8(int doIt){
if (doIt) {
    /* Test case data declarations */
    ForceClearAllDTC_State_EN expected_returnValue = CANTATA_DEFAULT_VALUE;
    ForceClearAllDTC_State_EN returnValue;
    /* Set global data */
    initialise_global_data();
    g_ForceClearDtcState_En = C_ForceClearDtc_Running;
    g_ClearSingleDtcState_En = C_ClearSingleDtc_Running;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_returnValue = 1;
    expected_g_ClearSingleDtcState_En = 1;
    expected_g_DemClearDTCReturnStatus_u8 = 0x06;

    START_TEST("27:test_RbAplCust_ForceClearDTCRun_4",
               "cover switch case #600: case C_ForceClearDtc_Running: switch #690: case DEM_CLEAR_MEMORY_ERROR");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("{{Dem_EvMemEventMemoryLocIteratorNew#default}{Dem_EvMemEventMemoryLocIteratorIsValid#default}{Dem_EvMemGetEventMemEventId#default}{Dem_DtcIdFromEventId#default}{Dem_DtcGetCode#default}{Dem_isDtcIdValid#default}{RbAplCust_IsValidForceClearDTC#default}{Dem_EvMemEventMemoryLocIteratorNext#default}{Dem_ClearDTC#DEM_CLEAR_MEMORY_ERROR}}");

            /* Call SUT */
            returnValue = RbAplCust_ForceClearDTCRun();

            /* Test case checks */
            CHECK_U_INT(returnValue, expected_returnValue);
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_RbAplCust_ForceClearDTCRun_9(int doIt){
if (doIt) {
    /* Test case data declarations */
    ForceClearAllDTC_State_EN expected_returnValue = CANTATA_DEFAULT_VALUE;
    ForceClearAllDTC_State_EN returnValue;
    /* Set global data */
    initialise_global_data();
    g_ForceClearDtcState_En = C_ForceClearDtc_Running;
    g_ClearSingleDtcState_En = C_ClearSingleDtc_Running;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_returnValue = 1;
    expected_g_ClearSingleDtcState_En = 1;
    expected_g_DemClearDTCReturnStatus_u8 = 0x01;

    START_TEST("28:test_RbAplCust_ForceClearDTCRun_5",
               "cover switch case #600: case C_ForceClearDtc_Running: switch #690: case default");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("{{Dem_EvMemEventMemoryLocIteratorNew#default}{Dem_EvMemEventMemoryLocIteratorIsValid#default}{Dem_EvMemGetEventMemEventId#default}{Dem_DtcIdFromEventId#default}{Dem_DtcGetCode#default}{Dem_isDtcIdValid#default}{RbAplCust_IsValidForceClearDTC#default}{Dem_EvMemEventMemoryLocIteratorNext#default}{Dem_ClearDTC#DEM_CLEAR_WRONG_DTC}}");

            /* Call SUT */
            returnValue = RbAplCust_ForceClearDTCRun();

            /* Test case checks */
            CHECK_U_INT(returnValue, expected_returnValue);
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_RbAplCust_ForceClearDTCRun_10(int doIt){
if (doIt) {
    /* Test case data declarations */
    ForceClearAllDTC_State_EN expected_returnValue = CANTATA_DEFAULT_VALUE;
    ForceClearAllDTC_State_EN returnValue;
    /* Set global data */
    initialise_global_data();
    g_ForceClearDtcState_En = C_ForceClearDtc_Running;
    g_ClearSingleDtcState_En = C_ClearSingleDtc_Finished;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_returnValue = 3;
    expected_g_ForceClearDtcState_En = 3;

    START_TEST("29:test_RbAplCust_ForceClearDTCRun_3",
               "cover switch case #600: case C_ClearSingleDtc_Finished");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("{{Dem_EvMemEventMemoryLocIteratorNew#default}{Dem_EvMemEventMemoryLocIteratorIsValid#default}{Dem_EvMemGetEventMemEventId#default}{Dem_DtcIdFromEventId#default}{Dem_DtcGetCode#default}{Dem_isDtcIdValid#default}{RbAplCust_IsValidForceClearDTC#default}{Dem_EvMemEventMemoryLocIteratorNext#default}{Dem_ClearDTC#default}}");

            /* Call SUT */
            returnValue = RbAplCust_ForceClearDTCRun();

            /* Test case checks */
            CHECK_U_INT(returnValue, expected_returnValue);
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_RbAplCust_ForceClearDTCRun_11(int doIt){
if (doIt) {
    /* Test case data declarations */
    ForceClearAllDTC_State_EN expected_returnValue = CANTATA_DEFAULT_VALUE;
    ForceClearAllDTC_State_EN returnValue;
    /* Set global data */
    initialise_global_data();
    g_ForceClearDtcState_En = C_ForceClearDtc_Running;
    g_ClearSingleDtcState_En = C_ClearSingleDtc_Failed;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_returnValue = 2;
    expected_g_ForceClearDtcState_En = 2;

    START_TEST("30:test_RbAplCust_ForceClearDTCRun_4",
               "cover switch case #600: case C_ClearSingleDtc_Finished");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("{{Dem_EvMemEventMemoryLocIteratorNew#default}{Dem_EvMemEventMemoryLocIteratorIsValid#default}{Dem_EvMemGetEventMemEventId#default}{Dem_DtcIdFromEventId#default}{Dem_DtcGetCode#default}{Dem_isDtcIdValid#default}{RbAplCust_IsValidForceClearDTC#default}{Dem_EvMemEventMemoryLocIteratorNext#default}{Dem_ClearDTC#default}}");

            /* Call SUT */
            returnValue = RbAplCust_ForceClearDTCRun();

            /* Test case checks */
            CHECK_U_INT(returnValue, expected_returnValue);
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_RbAplCust_ForceClearDTCRun_12(int doIt){
if (doIt) {
    /* Test case data declarations */
    ForceClearAllDTC_State_EN expected_returnValue = CANTATA_DEFAULT_VALUE;
    ForceClearAllDTC_State_EN returnValue;
    /* Set global data */
    initialise_global_data();
    g_ForceClearDtcState_En = C_ForceClearDtc_Running;
    g_ClearSingleDtcState_En = C_ClearSingleDtc_Running;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_returnValue = 1;
    expected_g_ClearSingleDtcState_En = 1;
    expected_g_DemClearDTCReturnStatus_u8 = 0x03;

    START_TEST("31:test_RbAplCust_ForceClearDTCRun_5",
               "cover switch case #600: case C_ForceClearDtc_Running: switch #690: case DEM_CLEAR_FAILED");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("{{Dem_EvMemEventMemoryLocIteratorNew#default}{Dem_EvMemEventMemoryLocIteratorIsValid#default}{Dem_EvMemGetEventMemEventId#default}{Dem_DtcIdFromEventId#default}{Dem_DtcGetCode#default}{Dem_isDtcIdValid#default}{RbAplCust_IsValidForceClearDTC#default}{Dem_EvMemEventMemoryLocIteratorNext#default}{Dem_ClearDTC#DEM_CLEAR_FAILED}}");

            /* Call SUT */
            returnValue = RbAplCust_ForceClearDTCRun();

            /* Test case checks */
            CHECK_U_INT(returnValue, expected_returnValue);
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_RbAplCust_ForceClearDTCRun_13(int doIt){
if (doIt) {
    /* Test case data declarations */
    ForceClearAllDTC_State_EN expected_returnValue = CANTATA_DEFAULT_VALUE;
    ForceClearAllDTC_State_EN returnValue;
    /* Set global data */
    initialise_global_data();
    g_ForceClearDtcState_En = C_ForceClearDtc_Failed;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_returnValue = 2;

    START_TEST("32:test_RbAplCust_ForceClearDTCRun_2",
               "cover switch case #600: case C_ForceClearDtc_Failed");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("{{Dem_EvMemEventMemoryLocIteratorNew#default}{Dem_EvMemEventMemoryLocIteratorIsValid#default}{Dem_EvMemGetEventMemEventId#default}{Dem_DtcIdFromEventId#default}{Dem_DtcGetCode#default}{Dem_isDtcIdValid#default}{RbAplCust_IsValidForceClearDTC#default}{Dem_EvMemEventMemoryLocIteratorNext#default}{Dem_ClearDTC#default}}");

            /* Call SUT */
            returnValue = RbAplCust_ForceClearDTCRun();

            /* Test case checks */
            CHECK_U_INT(returnValue, expected_returnValue);
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_RbAplCust_ForceClearDTCRun_14(int doIt){
if (doIt) {
    /* Test case data declarations */
    ForceClearAllDTC_State_EN expected_returnValue = CANTATA_DEFAULT_VALUE;
    ForceClearAllDTC_State_EN returnValue;
    /* Set global data */
    initialise_global_data();
    g_ForceClearDtcState_En = C_ForceClearDtc_Finished;
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_returnValue = 3;

    START_TEST("33:test_RbAplCust_ForceClearDTCRun_3",
               "cover switch case #600: case C_ForceClearDtc_Finished");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("{{Dem_EvMemEventMemoryLocIteratorNew#default}{Dem_EvMemEventMemoryLocIteratorIsValid#default}{Dem_EvMemGetEventMemEventId#default}{Dem_DtcIdFromEventId#default}{Dem_DtcGetCode#default}{Dem_isDtcIdValid#default}{RbAplCust_IsValidForceClearDTC#default}{Dem_EvMemEventMemoryLocIteratorNext#default}{Dem_ClearDTC#default}}");

            /* Call SUT */
            returnValue = RbAplCust_ForceClearDTCRun();

            /* Test case checks */
            CHECK_U_INT(returnValue, expected_returnValue);
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_RbAplCust_IsValidForceClearDTC(int doIt){
if (doIt) {
    /* Test case data declarations */
    Dem_DtcCodeType storedDtc = CANTATA_DEFAULT_VALUE;
    Std_ReturnType expected_returnValue = CANTATA_DEFAULT_VALUE;
    Std_ReturnType returnValue;
    /* Set global data */
    initialise_global_data();
    storedDtc = 1;
    g_ValidDTCList_ForceClearDTC[0] = 1;

    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_returnValue = 0x00;

    START_TEST("34:test_RbAplCust_IsValidForceClearDTC",
               "cover true #822: if(storedDtc == g_ValidDTCList_ForceClearDTC[l_index_u8])");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            returnValue = RbAplCust_IsValidForceClearDTC(storedDtc);

            /* Test case checks */
            CHECK_U_CHAR(returnValue, expected_returnValue);
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

void test_RbAplCust_IsValidForceClearDTC_1(int doIt){
if (doIt) {
    /* Test case data declarations */
    Dem_DtcCodeType storedDtc = CANTATA_DEFAULT_VALUE;
    Std_ReturnType expected_returnValue = CANTATA_DEFAULT_VALUE;
    Std_ReturnType returnValue;
    /* Set global data */
    initialise_global_data();
    storedDtc = 0;
    g_ValidDTCList_ForceClearDTC[0] = 1;

    /* Set expected values for global data checks */
    initialise_expected_global_data();
    expected_returnValue = 0x01;

    START_TEST("35:test_RbAplCust_IsValidForceClearDTC_1",
               "cover false #822: if(storedDtc == g_ValidDTCList_ForceClearDTC[l_index_u8])");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            returnValue = RbAplCust_IsValidForceClearDTC(storedDtc);

            /* Test case checks */
            CHECK_U_CHAR(returnValue, expected_returnValue);
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}

/*****************************************************************************/
/* Call Interface Control                                                    */
/*****************************************************************************/

/* Stub for function RBSYS_EnterCommonLockSysfast */
void RBSYS_EnterCommonLockSysfast(){
    REGISTER_CALL("RBSYS_EnterCommonLockSysfast");

    IF_INSTANCE("default") {
        return;
    }

    LOG_SCRIPT_ERROR("Call instance not defined.");
    return;
}

/* Stub for function RBSYS_ExitCommonLockSysfast */
void RBSYS_ExitCommonLockSysfast(){
    REGISTER_CALL("RBSYS_ExitCommonLockSysfast");

    IF_INSTANCE("default") {
        return;
    }

    LOG_SCRIPT_ERROR("Call instance not defined.");
    return;
}

/* Stub for function RbAplCust_ReadyToStartRoutine */
uint8 RbAplCust_ReadyToStartRoutine(RoutineControl_SupportedRIDs_EN l_EOLProcess){
    REGISTER_CALL("RbAplCust_ReadyToStartRoutine");

    IF_INSTANCE("default") {
        return CANTATA_DEFAULT_VALUE;
    }

    IF_INSTANCE("RBAPLCUST_RoutineStartPossible") {
        return RBAPLCUST_RoutineStartPossible;
    }

    IF_INSTANCE("RBAPLCUST_RoutineSameRunning") {
        return RBAPLCUST_RoutineSameRunning;
    }

    IF_INSTANCE("RBAPLCUST_RoutineOtherRunning") {
        return RBAPLCUST_RoutineOtherRunning;
    }

    LOG_SCRIPT_ERROR("Call instance not defined.");
    return CANTATA_DEFAULT_VALUE;
}

/* Stub for function RbAplCust_EolProcessStop */
void RbAplCust_EolProcessStop(){
    REGISTER_CALL("RbAplCust_EolProcessStop");

    IF_INSTANCE("default") {
        return;
    }

    LOG_SCRIPT_ERROR("Call instance not defined.");
    return;
}

/* Stub for function FUN_HMIIgOn2sCheck_B */
boolean FUN_HMIIgOn2sCheck_B(){
    REGISTER_CALL("FUN_HMIIgOn2sCheck_B");

    IF_INSTANCE("default") {
        return CANTATA_DEFAULT_VALUE;
    }

    IF_INSTANCE("TRUE") {
        return TRUE;
    }

    IF_INSTANCE("FALSE") {
        return FALSE;
    }

    LOG_SCRIPT_ERROR("Call instance not defined.");
    return CANTATA_DEFAULT_VALUE;
}

/* Stub for function Dem_DisableDTCSetting */
Dem_ReturnControlDTCSettingType Dem_DisableDTCSetting(Dem_DTCGroupType DTCGroup,
                                                      Dem_DTCKindType DTCKind){
    REGISTER_CALL("Dem_DisableDTCSetting");

    IF_INSTANCE("default") {
        return CANTATA_DEFAULT_VALUE;
    }

    LOG_SCRIPT_ERROR("Call instance not defined.");
    return CANTATA_DEFAULT_VALUE;
}

/* Stub for function RbAplCust_EraseFreezeFrameDataInfo */
void RbAplCust_EraseFreezeFrameDataInfo(){
    REGISTER_CALL("RbAplCust_EraseFreezeFrameDataInfo");

    IF_INSTANCE("default") {
        return;
    }

    LOG_SCRIPT_ERROR("Call instance not defined.");
    return;
}

/* Stub for function RbAplCust_CheckRoutineOperationVoltage */
Std_ReturnType RbAplCust_CheckRoutineOperationVoltage(){
    REGISTER_CALL("RbAplCust_CheckRoutineOperationVoltage");

    IF_INSTANCE("default") {
        return CANTATA_DEFAULT_VALUE;
    }

    IF_INSTANCE("E_NOT_OK") {
        return E_NOT_OK;
    }

    IF_INSTANCE("E_OK") {
        return E_OK;
    }

    LOG_SCRIPT_ERROR("Call instance not defined.");
    return CANTATA_DEFAULT_VALUE;
}

/* Stub for function RbAplCust_CheckAllWheelSpeed */
Std_ReturnType RbAplCust_CheckAllWheelSpeed(uint16_t param_1){
    REGISTER_CALL("RbAplCust_CheckAllWheelSpeed");

    IF_INSTANCE("default") {
        return CANTATA_DEFAULT_VALUE;
    }

    IF_INSTANCE("E_NOT_OK") {
        return E_NOT_OK;
    }

    IF_INSTANCE("E_OK") {
        return E_OK;
    }

    LOG_SCRIPT_ERROR("Call instance not defined.");
    return CANTATA_DEFAULT_VALUE;
}

/* Stub for function Dem_EvMemEventMemoryLocIteratorNew */
void Dem_EvMemEventMemoryLocIteratorNew(uint16_least * LocId,
                                        uint16_least MemId){
    REGISTER_CALL("Dem_EvMemEventMemoryLocIteratorNew");

    IF_INSTANCE("default") {
        return;
    }

    LOG_SCRIPT_ERROR("Call instance not defined.");
    return;
}

/* Stub for function Dem_EvMemEventMemoryLocIteratorIsValid */
Dem_boolean_least Dem_EvMemEventMemoryLocIteratorIsValid(const uint16_least * LocId,
                                                         uint16_least MemId){
    REGISTER_CALL("Dem_EvMemEventMemoryLocIteratorIsValid");

    IF_INSTANCE("default") {
        return CANTATA_DEFAULT_VALUE;
    }

    IF_INSTANCE("TRUE") {
        return TRUE;
    }

    IF_INSTANCE("FALSE") {
        return FALSE;
    }

    LOG_SCRIPT_ERROR("Call instance not defined.");
    return CANTATA_DEFAULT_VALUE;
}

/* Stub for function Dem_EvMemGetEventMemEventId */
Dem_EventIdType Dem_EvMemGetEventMemEventId(uint16_least LocId){
    REGISTER_CALL("Dem_EvMemGetEventMemEventId");

    IF_INSTANCE("default") {
        return CANTATA_DEFAULT_VALUE;
    }

    LOG_SCRIPT_ERROR("Call instance not defined.");
    return CANTATA_DEFAULT_VALUE;
}

/* Stub for function Dem_DtcIdFromEventId */
Dem_DtcIdType Dem_DtcIdFromEventId(Dem_EventIdType id){
    REGISTER_CALL("Dem_DtcIdFromEventId");

    IF_INSTANCE("default") {
        return CANTATA_DEFAULT_VALUE;
    }

    LOG_SCRIPT_ERROR("Call instance not defined.");
    return CANTATA_DEFAULT_VALUE;
}

/* Stub for function Dem_DtcGetCode */
Dem_DtcCodeType Dem_DtcGetCode(Dem_DtcIdType dtcId){
    REGISTER_CALL("Dem_DtcGetCode");

    IF_INSTANCE("default") {
        return CANTATA_DEFAULT_VALUE;
    }

    LOG_SCRIPT_ERROR("Call instance not defined.");
    return CANTATA_DEFAULT_VALUE;
}

/* Stub for function Dem_isDtcIdValid */
Dem_boolean_least Dem_isDtcIdValid(Dem_DtcIdType id){
    REGISTER_CALL("Dem_isDtcIdValid");

    IF_INSTANCE("default") {
        return CANTATA_DEFAULT_VALUE;
    }

    IF_INSTANCE("TRUE") {
        return TRUE;
    }

    IF_INSTANCE("FALSE") {
        return FALSE;
    }

    LOG_SCRIPT_ERROR("Call instance not defined.");
    return CANTATA_DEFAULT_VALUE;
}

/* Stub for function Dem_EvMemEventMemoryLocIteratorNext */
void Dem_EvMemEventMemoryLocIteratorNext(uint16_least * LocId,
                                         uint16_least MemId){
    REGISTER_CALL("Dem_EvMemEventMemoryLocIteratorNext");

    IF_INSTANCE("default") {
        return;
    }

    LOG_SCRIPT_ERROR("Call instance not defined.");
    return;
}

/* Stub for function Dem_ClearDTC */
Dem_ReturnClearDTCType Dem_ClearDTC(uint32 DTC,
                                    Dem_DTCFormatType DTCFormat,
                                    Dem_DTCOriginType DTCOrigin){
    REGISTER_CALL("Dem_ClearDTC");

    IF_INSTANCE("default") {
        return CANTATA_DEFAULT_VALUE;
    }

    IF_INSTANCE("DEM_CLEAR_OK") {
        return DEM_CLEAR_OK;
    }

    IF_INSTANCE("DEM_CLEAR_PENDING") {
        return DEM_CLEAR_PENDING;
    }

    IF_INSTANCE("DEM_CLEAR_MEMORY_ERROR") {
        return DEM_CLEAR_MEMORY_ERROR;
    }

    IF_INSTANCE("DEM_CLEAR_FAILED") {
        return DEM_CLEAR_FAILED;
    }

    IF_INSTANCE("DEM_CLEAR_WRONG_DTC") {
        return DEM_CLEAR_WRONG_DTC;
    }

    LOG_SCRIPT_ERROR("Call instance not defined.");
    return CANTATA_DEFAULT_VALUE;
}

#pragma qas cantata ignore on

/* Before-Wrapper for function RbAplCust_ForceClearDTCRun */
int BEFORE_RbAplCust_ForceClearDTCRun(){
    REGISTER_CALL("RbAplCust_ForceClearDTCRun");

    return REPLACE_WRAPPER;

    IF_INSTANCE("default") {
        return AFTER_WRAPPER;
    }

    LOG_SCRIPT_ERROR("Call instance not defined.");
    return AFTER_WRAPPER;
}

/* After-Wrapper for function RbAplCust_ForceClearDTCRun */
ForceClearAllDTC_State_EN AFTER_RbAplCust_ForceClearDTCRun(ForceClearAllDTC_State_EN cppsm_return_value){
    IF_INSTANCE("default") {
        return cppsm_return_value;
    }

    LOG_SCRIPT_ERROR("Call instance not defined.");
    return cppsm_return_value;
}

/* Replace-Wrapper for function RbAplCust_ForceClearDTCRun */
ForceClearAllDTC_State_EN REPLACE_RbAplCust_ForceClearDTCRun(){
    IF_INSTANCE("default") {
        return CANTATA_DEFAULT_VALUE;
    }

    IF_INSTANCE("C_ForceClearDtc_Starts") {
        return C_ForceClearDtc_Starts;
    }

    IF_INSTANCE("C_ForceClearDtc_Running") {
        return C_ForceClearDtc_Running;
    }

    IF_INSTANCE("C_ForceClearDtc_Finished") {
        return C_ForceClearDtc_Finished;
    }

    IF_INSTANCE("C_ForceClearDtc_Failed") {
        return C_ForceClearDtc_Failed;
    }

    LOG_SCRIPT_ERROR("Call instance not defined.");
    return CANTATA_DEFAULT_VALUE;
}

/* Before-Wrapper for function RbAplCust_IsValidForceClearDTC */
int BEFORE_RbAplCust_IsValidForceClearDTC(Dem_DtcCodeType storedDtc){
    REGISTER_CALL("RbAplCust_IsValidForceClearDTC");

    return REPLACE_WRAPPER;

    LOG_SCRIPT_ERROR("Call instance not defined.");
    return AFTER_WRAPPER;
}

/* After-Wrapper for function RbAplCust_IsValidForceClearDTC */
Std_ReturnType AFTER_RbAplCust_IsValidForceClearDTC(Std_ReturnType cppsm_return_value,
                                                    Dem_DtcCodeType storedDtc){
    IF_INSTANCE("default") {
        return cppsm_return_value;
    }

    LOG_SCRIPT_ERROR("Call instance not defined.");
    return cppsm_return_value;
}

/* Replace-Wrapper for function RbAplCust_IsValidForceClearDTC */
Std_ReturnType REPLACE_RbAplCust_IsValidForceClearDTC(Dem_DtcCodeType storedDtc){
    IF_INSTANCE("default") {
        return CANTATA_DEFAULT_VALUE;
    }

    IF_INSTANCE("E_OK") {
        return E_OK;
    }

    IF_INSTANCE("E_NOT_OK") {
        return E_NOT_OK;
    }

    LOG_SCRIPT_ERROR("Call instance not defined.");
    return CANTATA_DEFAULT_VALUE;
}

#pragma qas cantata ignore off
/* pragma qas cantata testscript end */
/*****************************************************************************/
/* End of test script                                                        */
/*****************************************************************************/
