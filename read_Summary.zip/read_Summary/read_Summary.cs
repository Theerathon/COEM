﻿using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using Excel = Microsoft.Office.Interop.Excel;

namespace read_Summary
{
    class read_Summary
    {
        static void Main(string[] args)
        {
            string filepath_in = args[0];
            Application xlApp = new Application();
            Workbook xlWorkbook = xlApp.Workbooks.Open(filepath_in);
            //Worksheet xlWorksheet = (Worksheet)xlWorkbook.Sheets.get_Item(1);

            //Excel.Application xlApp = new Excel.Application();
            //Excel.Workbook xlWorkbook = xlApp.Workbooks.Open(filepath_in);
            //Excel.Worksheet xlWorksheet = (Excel.Worksheet)xlWorkbook.Sheets.get_Item(1);
            //xlWorksheet22 = (Worksheet)xlWorkbook.Sheets["Test_Spec"];
            Worksheet xlWorksheet = (Worksheet)xlWorkbook.Sheets["COEM_Package_20200401"];
            xlWorksheet.Select(Type.Missing);
            Range xlRange = xlWorksheet.UsedRange;
            object[,] valueArray = (object[,])xlRange.get_Value(XlRangeValueDataType.xlRangeValueDefault);

            int pi = xlWorksheet.UsedRange.Rows.Count;
            Console.WriteLine(pi + "\n");
            bool check = false;
            int row_package = 0;
            int col_package = 0;
            int row_prj = 0;
            int col_prj = 0;
            int row_comp = 0;
            int col_comp = 0;
            int row_taskID = 0;
            int col_taskID = 0;
            int row_ItemName = 0;
            int col_ItemName = 0;
            int row_Tester = 0;
            int col_Tester = 0;
            try
            {
                for (int row = 1; row <= xlWorksheet.UsedRange.Rows.Count; ++row)
                {
                    for (int column = 1; column <= xlWorksheet.UsedRange.Columns.Count; ++column)
                    {
                        if(valueArray[row, column]!=null)
                        {
                            if(valueArray[row, column].ToString() == "Package")
                            {
                                string giatri = valueArray[row, column].ToString();
                                row_package = row;
                                col_package = column;
                                check = true;
                                //Console.WriteLine(giatri + "\n");
                                Console.WriteLine(row_package + "\n");
                                Console.WriteLine(col_package + "\n");
                                //break;
                            }
                            else if (valueArray[row, column].ToString() == "Project")
                            {
                                row_prj = row;
                                col_prj = column;
                                Console.WriteLine(row_prj + "\n");
                                Console.WriteLine(col_prj + "\n");
                            }
                            else if (valueArray[row, column].ToString() == "ComponentName")
                            {
                                row_comp = row;
                                col_comp = column;
                                Console.WriteLine(row_comp + "\n");
                                Console.WriteLine(col_comp + "\n");
                            }
                            else if (valueArray[row, column].ToString() == "TaskID")
                            {
                                row_taskID = row;
                                col_taskID = column;
                                Console.WriteLine(row_taskID + "\n");
                                Console.WriteLine(col_taskID + "\n");
                            }
                            else if (valueArray[row, column].ToString() == "ItemName")
                            {
                                row_ItemName = row;
                                col_ItemName = column;
                                Console.WriteLine(row_ItemName + "\n");
                                Console.WriteLine(col_ItemName + "\n");
                            }
                            else if (valueArray[row, column].ToString() == "Tester")
                            {
                                row_Tester = row;
                                col_Tester = column;
                                Console.WriteLine(row_Tester + "\n");
                                Console.WriteLine(col_Tester + "\n");
                            }
                            
                        }
                    }
                    if (check) break;
                }
            }
            catch { }

            //string giatri = valueArray[1, 1].ToString();
            //Console.WriteLine(giatri + "\n");
            xlWorkbook.Close(false, false, false);
            xlApp.Workbooks.Close();
            xlApp.Quit();
            System.Runtime.InteropServices.Marshal.ReleaseComObject(xlWorkbook);
            System.Runtime.InteropServices.Marshal.ReleaseComObject(xlApp);
        }
    }
}
