﻿using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using Excel = Microsoft.Office.Interop.Excel;
using System.Drawing;
using System.Windows.Media;
using ExcelDataReader;

namespace read_Summary
{
    class read_Summary
    {
        static void Main(string[] args)
        {
            string filepath_in = args[0];
            string listTask = args[1];
            string filepath_out = args[2];
            listTask = listTask.Replace(" ", "");

            //listTask.Replace(' ', null);
            string[] tach = listTask.Split(',', '.', '\r', '\n');
            List<string> a = new List<string>();
            a = tach.ToList();
            a = a.Distinct().ToList();
            Application xlApp = new Application();
            Workbook xlWorkbook = xlApp.Workbooks.Open(filepath_in);

            //Workbook xlWorkbook = xlApp.Workbooks.Open(filepath_in, false, true);
            //Worksheet xlWorksheet = (Worksheet)xlWorkbook.Sheets.get_Item(1);

            //Excel.Application xlApp = new Excel.Application();
            //Excel.Workbook xlWorkbook = xlApp.Workbooks.Open(filepath_in);
            //Excel.Worksheet xlWorksheet = (Excel.Worksheet)xlWorkbook.Sheets.get_Item(1);
            //xlWorksheet22 = (Worksheet)xlWorkbook.Sheets["Test_Spec"];
            Worksheet xlWorksheet = (Worksheet)xlWorkbook.Sheets["COEM_Package_20200401"];
            xlWorksheet.Select(Type.Missing);
            Range xlRange = xlWorksheet.UsedRange;
            object[,] valueArray = (object[,])xlRange.get_Value(XlRangeValueDataType.xlRangeValueDefault);

            int pi = xlWorksheet.UsedRange.Rows.Count;
            Console.WriteLine(pi + "\n");
            bool check = false;
            int row_package = 0;
            int col_package = 0;
            int row_prj = 0;
            int col_prj = 0;
            int row_comp = 0;
            int col_comp = 0;
            int row_taskID = 0;
            int col_taskID = 0;
            int row_ItemName = 0;
            int col_ItemName = 0;
            int row_Tester = 0;
            int col_Tester = 0;
            int rowyes = 0;
            int columnyes = 0;

            Excel.Application xlApp2;
            Workbook xlWorkBook2;
            Worksheet xlWorkSheet2;
            object misValue = System.Reflection.Missing.Value;

            xlApp2 = new Excel.Application();
            xlWorkBook2 = xlApp2.Workbooks.Add(misValue);
            xlWorkSheet2 = (Worksheet)xlWorkBook2.Worksheets.get_Item(1);
            int rowValue = 1;
            xlWorkSheet2.Cells[rowValue, 1] = "Project";
            xlWorkSheet2.Cells[rowValue, 1].EntireRow.Font.Bold = true;
            xlWorkSheet2.Cells[rowValue, 2] = "TaskID";
            xlWorkSheet2.Cells[rowValue, 2].EntireRow.Font.Bold = true;
            xlWorkSheet2.Cells[rowValue, 3] = "ItemName";
            xlWorkSheet2.Cells[rowValue, 3].EntireRow.Font.Bold = true;
            xlWorkSheet2.Cells[rowValue, 4] = "Tester";
            xlWorkSheet2.Cells[rowValue, 4].EntireRow.Font.Bold = true;
            xlWorkSheet2.Cells[rowValue, 5] = "ELOC Assigned";
            xlWorkSheet2.Cells[rowValue, 5].EntireRow.Font.Bold = true;
            xlWorkSheet2.Cells[rowValue, 5].Columns.Autofit();
            xlWorkSheet2.Cells[rowValue, 6] = "Status";
            xlWorkSheet2.Cells[rowValue, 6].EntireRow.Font.Bold = true;
            xlWorkSheet2.Cells[rowValue, 6].Columns.Autofit();
            xlWorkSheet2.Cells[rowValue, 7] = "Remark";
            xlWorkSheet2.Cells[rowValue, 7].EntireRow.Font.Bold = true;
            xlWorkSheet2.Cells[rowValue, 7].Columns.Autofit();

            try
            {
                for (int row = 30; row <= xlWorksheet.UsedRange.Rows.Count; ++row)
                {
                    for (int column = 1; column <= xlWorksheet.UsedRange.Columns.Count; ++column)
                    {
                        if (valueArray[row, column] != null)
                        {
                            if (valueArray[row, column].ToString() == "TaskID")
                            {
                                Console.WriteLine(row + "\n");
                                Console.WriteLine(column + "\n");
                                check = true;
                                rowyes = row;
                                columnyes = column;
                                break;
                            }

                            //if (valueArray[row, column].ToString() == "Package")
                            //{
                            //    string giatri = valueArray[row, column].ToString();
                            //    row_package = row;
                            //    col_package = column;
                            //    check = true;
                            //    //Console.WriteLine(giatri + "\n");
                            //    Console.WriteLine(row_package + "\n");
                            //    Console.WriteLine(col_package + "\n");
                            //    //break;
                            //}
                            //else if (valueArray[row, column].ToString() == "Project")
                            //{
                            //    row_prj = row;
                            //    col_prj = column;
                            //    Console.WriteLine(row_prj + "\n");
                            //    Console.WriteLine(col_prj + "\n");
                            //}
                            //else if (valueArray[row, column].ToString() == "ComponentName")
                            //{
                            //    row_comp = row;
                            //    col_comp = column;
                            //    Console.WriteLine(row_comp + "\n");
                            //    Console.WriteLine(col_comp + "\n");
                            //}
                            //else if (valueArray[row, column].ToString() == "TaskID")
                            //{
                            //    row_taskID = row;
                            //    col_taskID = column;
                            //    Console.WriteLine(row_taskID + "\n");
                            //    Console.WriteLine(col_taskID + "\n");
                            //}
                            //else if (valueArray[row, column].ToString() == "ItemName")
                            //{
                            //    row_ItemName = row;
                            //    col_ItemName = column;
                            //    Console.WriteLine(row_ItemName + "\n");
                            //    Console.WriteLine(col_ItemName + "\n");
                            //}
                            //else if (valueArray[row, column].ToString() == "Tester")
                            //{
                            //    row_Tester = row;
                            //    col_Tester = column;
                            //    Console.WriteLine(row_Tester + "\n");
                            //    Console.WriteLine(col_Tester + "\n");
                            //}

                            //}

                        }

                    }
                    if (check) break;
                }
            }
            catch { }
            check = false;
            rowyes++;
            try
            {
                for (; rowyes <= xlWorksheet.UsedRange.Rows.Count; rowyes++)
                {
                    foreach (string t in a)
                    {
                        //if (valueArray[rowyes, columnyes] != null)
                        //{
                        if (valueArray[rowyes, columnyes].ToString() == t)
                        {
                            xlWorkSheet2.Cells[++rowValue, 2] = valueArray[rowyes, columnyes].ToString();
                            xlWorkSheet2.Cells[rowValue, 1] = valueArray[rowyes, 5].ToString();
                            xlWorkSheet2.Cells[rowValue, 3] = valueArray[rowyes, 8].ToString();
                            xlWorkSheet2.Cells[rowValue, 4] = valueArray[rowyes, 15].ToString();
                            xlWorkSheet2.Cells[rowValue, 5] = valueArray[rowyes, 18].ToString();
                            if (valueArray[rowyes, 28] == null || valueArray[rowyes, 32] == null)
                            {
                                xlWorkSheet2.Cells[rowValue, 6] = "Check again!!!";
                                xlWorkSheet2.Cells[rowValue, 6].Interior.Color = XlRgbColor.rgbRed;
                            }
                            else if (valueArray[rowyes, 28].ToString().Equals("OK", StringComparison.Ordinal) && valueArray[rowyes, 32].ToString().Equals("N/A", StringComparison.Ordinal))
                            {
                                xlWorkSheet2.Cells[rowValue, 6] = "Done";
                            }
                            else if (valueArray[rowyes, 28].ToString().Equals("NG", StringComparison.Ordinal) && valueArray[rowyes, 32].ToString().Equals("OPL", StringComparison.Ordinal))
                            {
                                xlWorkSheet2.Cells[rowValue, 6] = "OPL";
                                xlWorkSheet2.Cells[rowValue, 6].Interior.Color = XlRgbColor.rgbYellow;
                            }
                            else if (valueArray[rowyes, 28].ToString().Equals("NG", StringComparison.Ordinal) && valueArray[rowyes, 32].ToString().Equals("Defect", StringComparison.Ordinal))
                            {
                                xlWorkSheet2.Cells[rowValue, 6] = "Defect";
                                xlWorkSheet2.Cells[rowValue, 6].Interior.Color = XlRgbColor.rgbRed;
                            }


                            if (valueArray[rowyes, 19] == null)
                            {
                                xlWorkSheet2.Cells[rowValue, 7] = "Check again";
                                xlWorkSheet2.Cells[rowValue, 7].Interior.Color = XlRgbColor.rgbRed;
                            }
                            else if (valueArray[rowyes, 18].ToString() != valueArray[rowyes, 19].ToString())
                            {
                                xlWorkSheet2.Cells[rowValue, 7] = "Actual ELOCS is " + valueArray[rowyes, 19].ToString();
                            }
                        }
                    }

                    if (check) break;
                }
            }
            catch { }

            xlWorkSheet2.Columns.AutoFit();

            //CellRange range = xlWorkSheet2.Range["B2:D4"];

            ((Range)xlWorkSheet2.get_Range("A1:G"+ rowValue)).Cells.Borders.LineStyle = XlLineStyle.xlContinuous;

            try
            {
                xlWorkBook2.SaveAs(filepath_out);
            }

            catch
            {
                //System.Runtime.InteropServices.COMException
                Console.WriteLine("Please close your opening excel file!!!");
                //Console.ReadKey();
                Console.Read();
            }

            //string giatri = valueArray[1, 1].ToString();
            //Console.WriteLine(giatri + "\n");
            xlWorkbook.Close(false, false, false);
            xlApp.Workbooks.Close();
            xlApp.Quit();
            System.Runtime.InteropServices.Marshal.ReleaseComObject(xlWorkbook);
            System.Runtime.InteropServices.Marshal.ReleaseComObject(xlApp);

            xlWorkBook2.Close(false, false, false);
            xlApp2.Workbooks.Close();
            xlApp2.Quit();
            System.Runtime.InteropServices.Marshal.ReleaseComObject(xlWorkBook2);
            System.Runtime.InteropServices.Marshal.ReleaseComObject(xlApp2);
        }
    }
}
