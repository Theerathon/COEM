﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Linq;
namespace Read_XML
{
    class ReadXML
    {
        static void Main(string[] args)
        {
            string filepath_in = args[0];
            List<string> listNameotherInputs = new List<string>();
            List<string> listTypeotherInputs = new List<string>();
            List<string> listNameInputs = new List<string>();
            List<string> listTypeInputs = new List<string>();


            foreach (var item in XElement.Load(filepath_in).Descendants("Elements").Elements("Element"))
            {
                //string k = "";
                //// If the element does not have any attributes
                //if (!item.Attributes().Any())
                //{
                //    // Lets skip it
                //    continue;
                //}
                //if(null != item.Elements("ElementAttributes").Elements("ScalarType"))
                //{
                //    if (null != item.Element("PrimitiveAttributes"))
                //    {
                //        k = item.Element("PrimitiveAttributes").Attribute("kind").Value;
                //    }
                //    else
                //    {
                //        k = "NULL";
                //    }
                //}


                // Obtain the value of your action attribute - Possible null reference exception here that should be handled
                var action = item.Attribute("name").Value;
                listNameotherInputs.Add(item.Attribute("name").Value);
                //var action2 = item.Attribute("kind").Value;
                // Obtain the value of your filename attribute - Possible null reference exception here that should be handled
                //var filename = item.Attribute("filename").Value;

                // Do something with your data
                //Console.WriteLine("action: {0}, filename {1}", action, filename);
                Console.WriteLine("Name: {0}", action);
                //Console.WriteLine("Type: {0}", k);
            }

            //foreach (var item in XElement.Load(filepath_in).Descendants("Elements").Elements("Element").Elements("ElementAttributes").Elements("ScalarType").Elements("PrimitiveAttributes"))
            foreach (var item in XElement.Load(filepath_in).Descendants("Elements").Elements("Element").Elements("ElementAttributes").Elements("ScalarType"))
            {
                // If the element does not have any attributes
                //if (!item.Attributes().Any())
                //{
                //    // Lets skip it
                //    continue;
                //}
                string action;
                if (null != item.Element("PrimitiveAttributes"))
                {
                    action = item.Element("PrimitiveAttributes").Attribute("kind").Value;
                    listTypeotherInputs.Add(item.Element("PrimitiveAttributes").Attribute("kind").Value);
                }
                else
                {
                    action = "NULL";
                    listTypeotherInputs.Add(action);
                }

                Console.WriteLine("action: {0}", action);

            }



            foreach (var item in XElement.Load(filepath_in).Descendants("Arguments").Elements("Argument"))
            {
                string action2;
                string nameofEnum = "";
                if (null != item.Element("ElementAttributes"))
                {
                    action2 = item.Element("ElementAttributes").Attribute("basicModelType").Value;
                    if (item.Element("ElementAttributes").Attribute("basicModelType").Value == "enumeration")
                    {
                        foreach (var item2 in XElement.Load(filepath_in).Descendants("Arguments").Elements("Argument").Elements("ElementAttributes").Elements("EnumerationAttributes"))
                        {
                            nameofEnum = item2.Attribute("enumerationName").Value;
                        }
                    }
                    else
                    {
                        nameofEnum = null;
                    }
                    listTypeInputs.Add(item.Element("ElementAttributes").Attribute("basicModelType").Value);

                }
                else
                {
                    action2 = "NULL";
                    listTypeInputs.Add(action2);
                }

                // If the element does not have any attributes
                if (!item.Attributes().Any())
                {
                    // Lets skip it
                    continue;
                }

                // Obtain the value of your action attribute - Possible null reference exception here that should be handled
                string action = item.Attribute("name").Value;
                listNameInputs.Add(item.Attribute("name").Value);

                // Do something with your data
                //Console.WriteLine("action: {0}, filename {1}", action, filename);
                Console.WriteLine("Name: {0}", action);
                Console.WriteLine("Type: {0}", action2);
                Console.WriteLine("NameofENUM: {0}", nameofEnum);
            }

            foreach (var item in XElement.Load(filepath_in).Descendants("EnumerationAttributes"))
            {
                string action2;
                //if (null != item.Element("EnumerationAttributes"))
                //{
                //    action2 = item.Element("EnumerationAttributes").Attribute("enumerationName").Value;                   
                //}
                //else
                //{
                //    action2 = "NULL";
                //    listTypeInputs.Add(action2);
                //}
                action2 = item.Attribute("enumerationName").Value;

                // If the element does not have any attributes
                if (!item.Attributes().Any())
                {
                    // Lets skip it
                    continue;
                }

                // Obtain the value of your action attribute - Possible null reference exception here that should be handled

                // Do something with your data
                //Console.WriteLine("action: {0}, filename {1}", action, filename);
                Console.WriteLine("Type: {0}", action2);
            }


        }
    }

}
