﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Linq;
using Excel = Microsoft.Office.Interop.Excel;
using Microsoft.Office.Interop.Excel;

namespace Read_XML
{
    class ReadXML
    {
        static void Main(string[] args)
        {

            Excel.Application xlApp;
            Excel.Workbook xlWorkBook;
            Excel.Worksheet xlWorkSheet;
            object misValue = System.Reflection.Missing.Value;

            xlApp = new Excel.Application();
            xlWorkBook = xlApp.Workbooks.Add(misValue);
            xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);

            int rowNAME = 10, columnNAME = 3, columnTYPE = 2;

            int ENUMinput = 0;

            xlWorkSheet.Cells[6, 2] = "Tolerance";
            xlWorkSheet.Cells[6, 2].EntireRow.Font.Bold = true;
            xlWorkSheet.Cells[7, columnTYPE] = "Type";
            xlWorkSheet.Cells[7, 2].EntireRow.Font.Bold = true;
            xlWorkSheet.Cells[8, 2] = "Max";
            xlWorkSheet.Cells[8, 2].EntireRow.Font.Bold = true;
            xlWorkSheet.Cells[9, 2] = "Min";
            xlWorkSheet.Cells[9, 2].EntireRow.Font.Bold = true;
            xlWorkSheet.Cells[10, 2] = "TC No.";
            xlWorkSheet.Cells[10, 2].EntireRow.Font.Bold = true;
            xlWorkSheet.Cells[rowNAME, columnNAME].Interior.Color = XlRgbColor.rgbGreen;
            xlWorkSheet.Cells[rowNAME, columnNAME] = "INPUTS";
            xlWorkSheet.Cells[rowNAME, columnNAME].EntireRow.Font.Bold = true;



            string filepath_in = args[0];
            string filepath_out = args[1];
            List<string> listNameotherInputs = new List<string>();
            List<string> listTypeotherInputs = new List<string>();
            List<string> listNameInputs = new List<string>();
            List<string> listTypeInputs = new List<string>();
            List<string> listkkkk = new List<string>();
            List<string> listENUMInputs = new List<string>();
            Hashtable hashLocalVariable = new Hashtable();
            Hashtable hashLocalParameter = new Hashtable();
            Hashtable hashLocalInput = new Hashtable();
            Hashtable hashImportedParameter = new Hashtable();

            List<string> listNameImportedParam = new List<string>();
            List<string> listTypeImportedParam = new List<string>();
            List<string> listTypVariable_otherInputs = new List<string>();

            List<string> listNameLocalParam = new List<string>();
            List<string> listTypeLocalParam = new List<string>();

            List<string> listNameLocalVari = new List<string>();
            List<string> listTypeLocalVari = new List<string>();


            foreach (var item in XElement.Load(filepath_in).Descendants("Elements").Elements("Element"))
            {
                string k = "";
                var action = item.Attribute("name").Value;

                if (null != item.Element("ElementAttributes"))
                {
                    k = item.Element("ElementAttributes").Attribute("basicModelType").Value;
                    listTypVariable_otherInputs.Add(k);
                }

                listNameotherInputs.Add(item.Attribute("name").Value);
                //Console.WriteLine("Name: {0}", action);
                //foreach (var item2 in XElement.Load(filepath_in).Descendants("Elements").Elements("Element").Elements("ElementAttributes").Elements("ScalarType").Elements("PrimitiveAttributes"))
                //{
                //    if (check == true) break;
                //    listkkkk.Add(item.Attribute("kind").Value);
                //    check = true;
                //}
                Console.WriteLine("action: {0}", action);
                Console.WriteLine("type of variable: {0}", k);
            }

            foreach (var item in XElement.Load(filepath_in).Descendants("Elements").Elements("Element").Elements("ElementAttributes").Elements("ScalarType"))
            {

                string action;
                if (null != item.Element("PrimitiveAttributes"))
                {
                    action = item.Element("PrimitiveAttributes").Attribute("scope").Value + " " + item.Element("PrimitiveAttributes").Attribute("kind").Value;
                    listTypeotherInputs.Add(item.Element("PrimitiveAttributes").Attribute("scope").Value + " " + item.Element("PrimitiveAttributes").Attribute("kind").Value);
                }
                else if (null != item.Element("EnumerationAttributes"))
                {
                    action = item.Element("EnumerationAttributes").Attribute("enumerationName").Value;
                    listTypeotherInputs.Add(item.Element("EnumerationAttributes").Attribute("enumerationName").Value);

                }
                else
                {
                    action = "NULL";
                    listTypeotherInputs.Add(action);
                }


                Console.WriteLine("Type: {0}", action);

            }

            foreach (var item in XElement.Load(filepath_in).Descendants("Arguments").Elements("Argument"))
            {
                string action2;
                string nameofEnum = "";
                if (null != item.Element("ElementAttributes"))
                {
                    action2 = item.Element("ElementAttributes").Attribute("basicModelType").Value;
                    if (item.Element("ElementAttributes").Attribute("basicModelType").Value == "enumeration")
                    {
                        foreach (var item2 in XElement.Load(filepath_in).Descendants("Arguments").Elements("Argument").Elements("ElementAttributes").Elements("EnumerationAttributes"))
                        {
                            nameofEnum = item2.Attribute("enumerationName").Value;
                        }
                    }
                    else
                    {
                        nameofEnum = null;
                    }
                    listTypeInputs.Add(item.Element("ElementAttributes").Attribute("basicModelType").Value);

                }
                else
                {
                    action2 = "NULL";
                    listTypeInputs.Add(action2);
                }

                // If the element does not have any attributes
                if (!item.Attributes().Any())
                {
                    // Lets skip it
                    continue;
                }

                // Obtain the value of your action attribute - Possible null reference exception here that should be handled
                string action = item.Attribute("name").Value;
                listNameInputs.Add(item.Attribute("name").Value);

                // Do something with your data
                //Console.WriteLine("action: {0}, filename {1}", action, filename);
                Console.WriteLine("Name: {0}", action);
                Console.WriteLine("Type: {0}", action2);
                Console.WriteLine("NameofENUM: {0}", nameofEnum);
            }

            //foreach (var item in XElement.Load(filepath_in).Descendants("EnumerationAttributes"))
            foreach (var item in XElement.Load(filepath_in).Descendants("Arguments").Elements("Argument").Elements("ElementAttributes").Elements("ScalarType").Elements("EnumerationAttributes"))
            {
                string action2;
                action2 = item.Attribute("enumerationName").Value;
                listENUMInputs.Add(item.Attribute("enumerationName").Value);
                // If the element does not have any attributes
                if (!item.Attributes().Any())
                {
                    // Lets skip it
                    continue;
                }

                // Obtain the value of your action attribute - Possible null reference exception here that should be handled

                // Do something with your data
                //Console.WriteLine("action: {0}, filename {1}", action, filename);
                Console.WriteLine("Type: {0}", action2);
            }
            for (int i = 0; i < listENUMInputs.Count; i++)
            {
                listENUMInputs[i] = listENUMInputs[i].Split('/').Last();
            }

            for (int i = 0; i < listNameotherInputs.Count; i++)
            {
                if (listTypeotherInputs[i] == "local variable")
                {
                    //hashLocalVariable.Add(listNameotherInputs[i], listTypeotherInputs[i]);
                    listNameLocalVari.Add(listNameotherInputs[i]);
                    listTypeLocalVari.Add(listTypVariable_otherInputs[i]);
                }
                else if (listTypeotherInputs[i] == "local parameter")
                {
                    //hashLocalParameter.Add(listNameotherInputs[i], listTypeotherInputs[i]);
                    listNameLocalParam.Add(listNameotherInputs[i]);
                    listTypeLocalParam.Add(listTypVariable_otherInputs[i]);
                }
                else if (listTypeotherInputs[i] == "imported parameter")
                {
                    //hashImportedParameter.Add(listNameotherInputs[i], listTypeotherInputs[i]);
                    listNameImportedParam.Add(listNameotherInputs[i]);
                    listTypeImportedParam.Add(listTypVariable_otherInputs[i]);
                }
            }

            rowNAME++;
            for (int i = 0; i < listNameInputs.Count; i++)
            {
                columnTYPE++;
                xlWorkSheet.Cells[rowNAME, columnNAME] = listNameInputs[i];
                if (listTypeInputs[i] == "enumeration")
                {
                    xlWorkSheet.Cells[7, columnTYPE] = listENUMInputs[ENUMinput];
                    ENUMinput++;
                }
                else
                {
                    xlWorkSheet.Cells[7, columnTYPE] = listTypeInputs[i];
                }
                columnNAME++;
            }
            columnTYPE++;

            if (listNameImportedParam != null)
            {
                xlWorkSheet.Cells[--rowNAME, columnNAME].Interior.Color = XlRgbColor.rgbYellow;
                rowNAME++;

                xlWorkSheet.Cells[10, columnNAME] = "IMPORTED PARAMETERS";
                for (int i = 0; i < listNameImportedParam.Count; i++)
                {
                    xlWorkSheet.Cells[11, columnNAME] = listNameImportedParam[i];
                    xlWorkSheet.Cells[7,  columnTYPE] = listTypeImportedParam[i];
                    columnTYPE++;
                    columnNAME++;
                }
            }

            if (listNameLocalParam != null)
            {
                xlWorkSheet.Cells[--rowNAME, columnNAME].Interior.Color = XlRgbColor.rgbKhaki;
                rowNAME++;

                xlWorkSheet.Cells[10, columnNAME] = "LOCAL PARAMETERS";
                for (int i = 0; i < listNameLocalParam.Count; i++)
                {
                    xlWorkSheet.Cells[11, columnNAME] = listNameLocalParam[i];
                    xlWorkSheet.Cells[7, columnTYPE] = listTypeLocalParam[i];
                    columnTYPE++;
                    columnNAME++;
                }
            }

            if (listNameLocalVari != null)
            {
                xlWorkSheet.Cells[--rowNAME, columnNAME].Interior.Color = XlRgbColor.rgbHotPink;
                rowNAME++;

                xlWorkSheet.Cells[10, columnNAME] = "LOCAL VARIABLES";
                for (int i = 0; i < listNameLocalVari.Count; i++)
                {
                    xlWorkSheet.Cells[11, columnNAME] = listNameLocalVari[i];
                    xlWorkSheet.Cells[7, columnTYPE] = listTypeLocalVari[i];
                    columnTYPE++;
                    columnNAME++;
                }
            }

            xlWorkSheet.Columns.AutoFit();
            //Range rng = (Range)xlWorkSheet.get_Range(xlWorkSheet.Cells[6, 2], xlWorkSheet.Cells[11, columnNAME]);


            //int countRows = xlWorkSheet.UsedRange.Rows.Count;
            //int countColumns = xlWorkSheet.UsedRange.Columns.Count;
            //object[,] data = xlWorkSheet.Range[xlWorkSheet.Cells[6, 2], xlWorkSheet.Cells[countRows, countColumns]].Cells.Value2;

            xlWorkSheet.get_Range((Range)xlWorkSheet.Cells[6, 2], (Range)xlWorkSheet.Cells[11, --columnNAME]).Cells.Borders.LineStyle = XlLineStyle.xlContinuous;

            try
            {
                xlWorkBook.SaveAs(filepath_out);
            }

            catch
            {
                //System.Runtime.InteropServices.COMException
                Console.WriteLine("Please close your opening excel file!!!");
                //Console.ReadKey();
                Console.Read();
            }


            xlWorkBook.Close(false, false, false);
            xlApp.Workbooks.Close();
            xlApp.Quit();
            System.Runtime.InteropServices.Marshal.ReleaseComObject(xlWorkBook);
            System.Runtime.InteropServices.Marshal.ReleaseComObject(xlApp);

        }
    }

}
