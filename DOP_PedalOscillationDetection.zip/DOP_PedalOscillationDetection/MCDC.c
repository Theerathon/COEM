// =========================================================================
// DESCRIPTION: 
// The oscillation can be caused if the input rod plunge is banged
// against the valve body.
// the bang can be recognized by 2 conditions
// a: before bang, the negative pedal velocity very high and 
// the certain negative drr is overcome, and accelaration is negative too
// b: after bang, the resulted pedal acceleration and jerk must be 
// big enough positive.
// After the oscillation is detected, the a time window must be defined 
// to avoid fast resetting of Detection flag, because
// oscillation becomes weaker due to bang energie reduced by time, the detection
// can not be working anymore.
//--------------------------------------------------------------------------
//2015 RBEI/ESB2 - Hegde, Sampat - Migrated class from LBR to DOP, modified logic.
//2016.12.07 RBEI/ESB2 - Hegde, Sampat - Added offset handling for Air Gap Compnesation
// ====================================================================================
/* Copy input datas to local variables */
DOP_DSO_AGC_TargetOffset = in_DSO_AGC_Offset;
DOP_n1 = in_DOP_n1;
//Calculate when the driver on pedal threshold will be
DriverOnPedalApplyThreshold = P_DoP_StrokeDiffPedalApplied.getAt(in_ActuatorPosition) - DOP_DSO_AGC_TargetOffset;

//calculate pedal acceleration and jerk
DInpVel = (in_vInputRod - InpVelCorrK1);
DInpVelCorrK1 = (InpVelCorrK1 - InpVelCorrK2);
DDInpVel = DInpVel - DInpVelCorrK1;
DifferentialStroke=in_DifferentialStroke;
PSCSpeedActual = in_PSCSpeedActual;

//Is Input Rod moving backwards?
if(in_vInputRod < 0) 1
{
	//Is the gap 'b' closing? / Within *BANG* limits
	if(	in_DifferentialStroke < P_DrrMin ) 2
	{
		//Is gap 'b' closing very fast?
		//of multiplying drr by pedal velocity (are we accelerating towards closure?)
		if ((DInpVel<P_InpAccelNegLimit)
			&&(in_vInputRod * in_DifferentialStroke > P_DrrMultivInpLimit )) 3//BANG potential is high (speed + proximity to bang)
		{
			//*BANG*can happen
			IsBangPossible = true;
			//Both cannot be true at same time
			IsBangOccurred = false;
		}
		else
		{
			if(!IsBangOccurred) 4
			{
				IsBangOccurred=((IsBangPossible) //Was *BANG* possible until now?
					&&(DInpVel > P_InpAccelPosLimit )&&(DDInpVel> P_InpJerkLimit)); //positive acceleration and jerk?
			}
			if(IsBangOccurred) 5
			{
				IsBangPossible = false;	
				//Bang possible and occured are mutually exclusive events.
			}
		}
	}
	else
	{
		// reset the flags.
		IsBangPossible = false;
	}
}
else
{
	// reset the flags.
	IsBangPossible = false;	
}

//bang occurs --> accl positive
//if pedal oscilating, then accl will become negative on way back --> reset bang (bang over at accl more neg than -10)
//what if its a real, small apply after bang occured? (to 0.5drr --> Pedal oscl will not reset until window over ok, but bang occured will also never reset)
//Hence reset the bang along wth pedal oscillation @ window over. if bang possible or occured again, window wont be zero :)
if ((DInpVel<0)&&(IsBangOccurred)) 6
{
	IsBangOccurred = false;
}

//if *BANG* has occured then we must re-check if the *BANG* can occur all over again
if(!PedalOscillationDetected) 7
{
	// we must set POD before DOP sets wrongly, so POD can SET if DRR more positive than -2.0
	if((IsBangOccurred)&&(in_DifferentialStroke >= (DriverOnPedalApplyThreshold - P_DOP_DRR_Tolerance))) 8
	{
		PedalOscillationDetected = true;
	}
}

/*-------------------------RESET Conditon--------------------------------*/
if(PedalOscillationDetected) 9
{
	//Hard reapply detection..Drr is very big
	if((in_DifferentialStroke > P_ResetMaxDrr)) 10
	{
		PedalOscillationDetected = false;
	}
	else
	{
		/*but brake pedal accelerating is positive*/
		/*meaning the driver apply pedal perhaps*/
		if(DInpVel > P_InpPosAccelResetlimit) 11
		{
			/*Drr big enough*/
			if(in_DifferentialStroke > P_DeactivationDrrLimit) 12
			{
				PedalOscillationDetected = false;
			}
		}
	}
}

/*------------------------------Oscillation Window-----------------------*/
//time window activated
//if the detection for one cycle not working
//or the oscillation energy damped by time
if(PedalOscillationDetected) 13
{
	//minimum time 60ms waiting time
	if(IsBangPossible)14 //again after once 14
	{
		OscillationWindow = P_MinWindowLength;
	}
	// maximum time nearly 100ms waiting time
	if(IsBangOccurred) 15
	{
		OscillationWindow = P_MaxWindowLength;
	}
	if(OscillationWindow == 0.0) 16
	{
		PedalOscillationDetected = false;
		IsBangOccurred = false;
	}
	else
	{
		//reduce  the counter
		OscillationWindow--;		
	}
}
else
{   //default zero
	OscillationWindow = 0.0;
}

// Addtional logic to catch, if gap b was closed, and we suddenly have a fast backward movement of actuator that will cause DRR to show a value 
// greater than DOP Applied threshold. We want to mask the DOP if it is possible that DOP will set wrongly

//Count Xms or if DRR is too high, allow DOP calculation
if((MaskDOPCounter >= P_DOP_MaskTime ) || ( DifferentialStroke > P_DOP_DRRHigh_Threshold)) 17
{		
	WrongDOPPossible = false;
	MaskDOPCounter = 0;
}		
else //check if the Actuator is moving very fast backward and input rod is not moving backwards (indicatedd by positive rate of DRR) mask the DOP in such situation.
{  
	if(((((DifferentialStroke-DifferentialStroke_K1)/P_CycleTime) > P_DRR_RateHigh_Threshold) && ((in_PSCSpeedActual < 0.0)|| (((PSCSpeedActual-PSCSpeedActual_K1)/P_CycleTime) < P_PSCActualSpeedGrad_Threshold))&& (WrongDOPPossible == false) && (DOP_n1 == false))
	||(WrongDOPPossible == true)) 18
		{
			WrongDOPPossible = true;
			MaskDOPCounter = MaskDOPCounter+1;
		}	
		//everything is fine
}

//Consider both possibility to mask DOP
if (PedalOscillationDetected || WrongDOPPossible ) 19
{
	MaskDOP = true;
}
else
{
	MaskDOP = false;
}


/* Copy values for next cycle */
InpVelCorrK2 = InpVelCorrK1;
InpVelCorrK1 = in_vInputRod;
DifferentialStroke_K1=DifferentialStroke;
PSCSpeedActual_K1 = PSCSpeedActual;
//================================================================================================
