/* Monitoring of AEB activation time
  AEB-IB: Maximum time defined by maximum velocity decrease and time parameter
  AEB-BA: Maximum time defined by time parameter
*/

/* Define velocity at AEB-Start: */

//GEE20 project specific requirement
//REQ: 142537	AEB allowed speed reduction
//REQ: 84093	AEB/ELKA denied
//The vehicle speed reference value is not allowed to be updated within 3 s after AsySftyEnaDecel changes from ’On’ to ‘Off’, 
//unless a new AEB activation is requested by AsySftyEnaDecel =’On’ AND the actual vehicle speed > stored vehicle speed reference value. 
/* confirmed with Geely, use below understanding.
delta_V_max(kph)                delat_t(s) [14 points]
47 [13.055 m/s]					1.5(0--1.5s)
47 [13.055 m/s]					1.5(1.5--1.6s)
48 [13.333] 					1.6(1.6--1.7s)
49 [13.611]					    1.7(1.7--1.8s)
50 [13.888] 					1.8(1.8--1.9s)
51 [14.166] 					1.9(1.9--2.0s)
52 [14.444] 					2.0(2.0--2.1s)
53 [14.722] 					2.1(2.1--2.2s)
54 [15] 					    2.2(2.2--2.3s)
56 [15.555] 					2.3(2.3--2.4s)
58 [16.111] 					2.4(2.4--2.5s)
60 [16.666] 					2.5(2.5--2.6s)
62 [17.222]					    2.6(2.6--2.7s)
63 [17.5]					   >2.7(2.7--[bigger] s)
*/

// part 1. GetAEBServiceType
// 147602, rcta enable condition, v in (0,18km/h)
//(RctaBrkReq && GearVehMovDir == VehMovDir_Backward && VxAct <= C_AEB_RCTA_Enable_MaxVelocity)
//RCTA,reverse gear and v<18km/h is checked and export by CM_AebDecCtrlAct from CM module.
if (RctaBrkReq && GearVehMovDir == VehMovDir_Backward && AEBDecCtrlAct == true) // CM_AebDecCtrlAct
{
    AEB_Servicetype = AEB_ServiceType_RCTA; //RCTA
} 1
else if (GearVehMovDir != VehMovDir_Backward 
         && AsyLatCtrlModReq == AsyLatCtrlModReq_EmgyLaneKeepAidForStat
		 && AEBDecCtrlAct == true ) 2                                   //ELKA
{
    AEB_Servicetype = AEB_ServiceType_ELKA; //ELKA
}
else if (GearVehMovDir != VehMovDir_Backward && AEBDecCtrlAct == true) //AEB / FCTA / Brake Gain(DBS)
{
    AEB_Servicetype = AEB_ServiceType_AEB_FCTA_DBS; //AEB/DBS/FCTA
} 3
else
{
    AEB_Servicetype = AEB_ServiceType_NoRequest;         // No Request
}

// part 2. actions taken in the status changing edge
// update the time interval, accumulated active time, and the speed drop limit
// start to update the AEB speed drop ref value,
// AEB_ReferenceSpeed is the continous actions speed ref,  AEB_v_Init is the individual action speed ref, 
//2.1 rising edge,total new AEB action, time interval with prev one is beyond 3s.
if( (AsyDecelEna_K1 == false && AsyDecelEna == true && !AEB_ContinuedAction_B) //rising edge
	|| (AEB_ServicetypeK1 !=AEB_ServiceType_RCTA && AEB_Servicetype == AEB_ServiceType_RCTA)) 4// or rcta
{
	AEBDecCtrlAct2Inact = false;
	AEB_edge_detection = AEB_ActionEdgeType_RisingEdge;	//rising edge , use enum
	AEB_Servicetype_current = AEB_Servicetype;
	
	AEB_ReferenceSpeed = VxAct;
	AEB_v_Init = VxAct;
	tAEBActionInterval = 0;
	tAEB_ActiveTimeSum = 0;

}
//2.2 rising edge,new AEB action but time interval with prev one is within 3s,
// use the previous speed drop ref AEB_ReferenceSpeed,but update the individual brake speed ref
else if( AsyDecelEna_K1 == false && AsyDecelEna == true && AEB_ContinuedAction_B ) 5//rising edge
{
	AEBDecCtrlAct2Inact = false;
	AEB_edge_detection = AEB_ActionEdgeType_RisingEdge;	//rising edge
	AEB_Servicetype_current = AEB_Servicetype;
	
	AEB_v_Init = VxAct;
	// tAEB_ActiveTimeSum = tAEB_ActiveTimeSum_prev;
	// still accumulate the active time in the inactive time interval of the consecutive AEB actions within 3s.
    tAEB_ActiveTimeSum = tAEB_ActiveTimeSum + C_dtAEB_5ms;
	tAEBActionInterval = 0;
	
}
//2.3 failing edge, one AEB action finished, 
if((AsyDecelEna_K1 == true) && (AsyDecelEna == false)) 6// falling edge
{
	AEBDecCtrlAct2Inact = true;
	AEB_edge_detection = AEB_ActionEdgeType_FailingEdge;	//falling edge
	AEB_Servicetype_prev = AEB_ServicetypeK1;
	
	tAEB_ActiveTimeSum_prev = tAEB_ActiveTimeSum;
}


// part 3, update tAEB_ActiveTimeSum and the AEB time interval in 2 AEB actions.
//3.1 total new AEB action, time interval with prev one is beyond 3s.
if( (AEBDecCtrlAct && !AEB_ContinuedAction_B)
	|| (AEB_Servicetype==AEB_ServiceType_RCTA)) 7
{
	if(tAEB_ActiveTimeSum < C_AEB_IB_MaxActivationTime)	8	// max active time is 10s
	{
		tAEB_ActiveTimeSum = tAEB_ActiveTimeSum + C_dtAEB_5ms;
	}
	else
	{
		tAEB_ActiveTimeSum = C_AEB_IB_MaxActivationTime;//parameter old name C_tSpeedAllowedMax
	}	
	tAEBActionInterval = 0;
	AEB_MaxVelocityDrop_loc = P_AEB_IB_MaxVelocityDrop_Curve.getAt(tAEB_ActiveTimeSum); // update AEB_MaxVelocityDrop_loc 
	//AEB_IB_MaxActivationTime_loc = C_AEB_IB_MaxActivationTime;// use constant parameter value 10s.
	
}
//3.2 new AEB action but time interval with prev one is within 3s, for both ELKA and AEB
else if(AEBDecCtrlAct && AEB_ContinuedAction_B) 9
{
	if(tAEB_ActiveTimeSum < C_AEB_IB_MaxActivationTime)	10	// max active time is 10s
	{
		tAEB_ActiveTimeSum = tAEB_ActiveTimeSum + C_dtAEB_5ms;
	}
	else
	{
		tAEB_ActiveTimeSum = C_AEB_IB_MaxActivationTime;		//parameter old name C_tSpeedAllowedMax
	}	
	
	tAEBActionInterval = 0;
	AEB_MaxVelocityDrop_loc = P_AEB_IB_MaxVelocityDrop_Curve.getAt(tAEB_ActiveTimeSum); // update AEB_MaxVelocityDrop_loc 
	//AEB_IB_MaxActivationTime_loc = C_AEB_IB_MaxActivationTime;// use constant parameter value 10s.
		
} 
//3.3 one AEB action finished, inactive phase.
//need calculate the AEB inactive time interval and save the AEB active time counter
else if (AEBDecCtrlAct2Inact == true && AEBDecCtrlAct == false) 11
{	
	if(tAEBActionInterval < C_tSameSpeedDropMaxInterval) 12// AEB time interval counter, max value is 3s
	{
		tAEBActionInterval = tAEBActionInterval + C_dtAEB_5ms;
		AEB_ContinuedAction_B = true;
		// still accumulate the active time in the inactive time interval of the consecutive AEB actions within 3s.
        tAEB_ActiveTimeSum = tAEB_ActiveTimeSum + C_dtAEB_5ms;
	}
	else
	{
		tAEBActionInterval = C_tSameSpeedDropMaxInterval;//parameter old name C_tSpeedAllowedMax
		AEB_ContinuedAction_B = false;
		tAEB_ActiveTimeSum = 0;	
	}
	
}
//////////////////
// part 4. Logic to check if Speed Drop crossed or not 
// the speed VxAct input should be positive value, if not ,need use "AEB_ReferenceSpeed.abs() - VxAct.abs()"
// [RCTA only enable in (1,18km/h), speed drop cannot cross 5m/s, no need check.]

// update the reference speed if actual speed increased bigger than AEB_ReferenceSpeed in the combined AEB action
// used to ensure the (AEB_CombinedSpeedDrop > AEB_IndividualSpeedDrop).
if ( VxAct > AEB_ReferenceSpeed && tAEB_ActiveTimeSum > 0 
	 && (AEB_Servicetype == AEB_ServiceType_ELKA || AEB_Servicetype == AEB_ServiceType_AEB_FCTA_DBS )) 13
{
	 AEB_ReferenceSpeed = VxAct;
}
//
AEB_CombinedSpeedDrop = AEB_ReferenceSpeed - VxAct;
AEB_IndividualSpeedDrop = AEB_v_Init - VxAct;

//4.1 check both individual and accumulated Speed Drop when current AEB service is ELKA.
if ((AEB_Servicetype == AEB_ServiceType_ELKA) 
     && (AEB_IndividualSpeedDrop > C_AEB_ELKA_MaxVelocityDrop || AEB_CombinedSpeedDrop > AEB_MaxVelocityDrop_loc)) 14
{
	AEB_speedDropBeyondLimit_B =  true;
}
//4.2 check accumulated speed drop for AEB,FCTA,(including before excuted ELKA actions).
//no need check individual, individual is surely less than accumulated drop.
else if (   (AEB_Servicetype == AEB_ServiceType_AEB_FCTA_DBS) 
		 && ( AEB_CombinedSpeedDrop > AEB_MaxVelocityDrop_loc )  ) 15
{
	AEB_speedDropBeyondLimit_B =  true;
}
else
{
	AEB_speedDropBeyondLimit_B =  false;
}

//Req 142537, AEB/ELKA/FCTA speed reduction limit
//AEB(FCTA)/ELKA should not have speed limit when AsySftyEnaDecelByDBS = "On" 
// confirmed by tengfei, if AsySftyEnaDecelByDBS == true, remove speed limit for all scenarios.
if( AsySftyEnaDecelByDBS == true ) 16
{
	AEB_IB_MaxVelocityDrop_B = false;		// flag used to report FW_MaxVelocityDropReached_B[curable] in CM module,
}
else 
{
	AEB_IB_MaxVelocityDrop_B = AEB_speedDropBeyondLimit_B;	
}

AEB_IB_MaxTimeReached_B = (tAEB > C_AEB_IB_MaxActivationTime);

AEB_BA_MaxTimeReached_B = (tAEB > C_AEB_BA_MaxActivationTime);



AEBDecCtrlAct_K1 = AEBDecCtrlAct;
AsyDecelEna_K1 = AsyDecelEna;
AEB_ServicetypeK1 = AEB_Servicetype;
