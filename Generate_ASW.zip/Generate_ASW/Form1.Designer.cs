﻿namespace Generate_ASW
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textNameClass = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textPathInput = new System.Windows.Forms.TextBox();
            this.btn_Generate = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.Outputpath = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textNameClass
            // 
            this.textNameClass.Location = new System.Drawing.Point(12, 55);
            this.textNameClass.Name = "textNameClass";
            this.textNameClass.Size = new System.Drawing.Size(336, 20);
            this.textNameClass.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 30);
            this.label1.Name = "label1";
            this.label1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label1.Size = new System.Drawing.Size(75, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Name of Class";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 105);
            this.label2.Name = "label2";
            this.label2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label2.Size = new System.Drawing.Size(68, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Path of Input";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // textPathInput
            // 
            this.textPathInput.Location = new System.Drawing.Point(12, 130);
            this.textPathInput.Multiline = true;
            this.textPathInput.Name = "textPathInput";
            this.textPathInput.Size = new System.Drawing.Size(400, 50);
            this.textPathInput.TabIndex = 2;
            // 
            // btn_Generate
            // 
            this.btn_Generate.Location = new System.Drawing.Point(401, 44);
            this.btn_Generate.Name = "btn_Generate";
            this.btn_Generate.Size = new System.Drawing.Size(74, 41);
            this.btn_Generate.TabIndex = 4;
            this.btn_Generate.Text = "Generate";
            this.btn_Generate.UseVisualStyleBackColor = true;
            this.btn_Generate.Click += new System.EventHandler(this.btn_Generate_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 200);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Output:";
            // 
            // Outputpath
            // 
            this.Outputpath.AutoSize = true;
            this.Outputpath.Location = new System.Drawing.Point(12, 227);
            this.Outputpath.MaximumSize = new System.Drawing.Size(400, 200);
            this.Outputpath.MinimumSize = new System.Drawing.Size(400, 40);
            this.Outputpath.Name = "Outputpath";
            this.Outputpath.Size = new System.Drawing.Size(400, 40);
            this.Outputpath.TabIndex = 6;
            this.Outputpath.Click += new System.EventHandler(this.Outputpath_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(508, 291);
            this.Controls.Add(this.Outputpath);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btn_Generate);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textPathInput);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textNameClass);
            this.Name = "Form1";
            this.Text = "Generate_ASW";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.DoubleClick += new System.EventHandler(this.Form1_DoubleClick);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textNameClass;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textPathInput;
        private System.Windows.Forms.Button btn_Generate;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label Outputpath;
    }
}

