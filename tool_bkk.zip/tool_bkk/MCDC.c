/* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
/* calculate force balance in order to decide if additional */
/* pressure build up for standstill is necessary            */
/* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */

/* --------------------------------------------------------- */
/* calculation is only done as long as Fx control phase of   */
/* LFC is active and the velocity is above threshold		 */
/* --------------------------------------------------------- */


if((LfcReqSSM == LFCReqSSM_Standstill) && (vVeh >= (P_LFCvCalcRollout+P_LFCvHystRollout))&& (LfcRollout_B == false)) 
{
	LfcFxCtrlNearSSM = false;
}
else if(((LfcReqSSM == LFCReqSSM_Standstill) && (vVeh < P_LFCvCalcRollout)) || ((LfcState == LFC_StandBy) && (LfcReqSSM == LFCReqSSM_FxControl)))
{
	LfcFxCtrlNearSSM = true;
}

if (LfcFxCtrlNearSSM == false)
{

   LfcFxTarRollout = LDMAxF * C_m_Vehicle;
   /* initialize filter */
   if (LfcFxCtrlNearSSMK1 == true)
   {
      LfcFxVehF = FxVeh;    
   }

   // LfcFxVehF = LfcFxVehF + (FxVeh - LfcFxVehF) * P_FiFxActRoll_b0;
   /* rounding construction */
   l_Delta_FxVehF = (FxVeh - LfcFxVehF);
   if (l_Delta_FxVehF == 0.0)
   {l_FxVehF_AbsIncr = 0.0;}
   else
   {   /* calculate absolute values of filter increment */
       l_FxVehF_AbsIncr = P_FiFxActRoll_b0 * (l_Delta_FxVehF.abs()) + (P_OneBit_Fx/2.0);
       l_FxVehF_AbsIncr = l_FxVehF_AbsIncr.max(P_OneBit_Fx);
       /* increment/decrement filtered value recognizing sign of filter deviation */
       if (l_Delta_FxVehF < 0.0)
       {LfcFxVehF = LfcFxVehF - l_FxVehF_AbsIncr;}
       else
       {LfcFxVehF = LfcFxVehF + l_FxVehF_AbsIncr;}
   }

   /* ---------------------------------- */
   /* --- necessary additional force --- */
   /* ---------------------------------- */
   LfcTrq2FxVeh.calc(MPropF,Co_FA);
   LfcFxMPropF = LfcTrq2FxVeh.FxVeh();
   /* make sure, that the force based on propulsion torque is at least 0 if forward gear is selected and is 0, if forward gear is not selected */
   if ((TarGearStep >= 1)||(TarGearStep == -1))
   {
      LfcFxMPropF = LfcFxMPropF.abs();
   }
   else
   {
      LfcFxMPropF = 0.0;
   }
   LfcFxDeltaTarRoll = LfcFxTarRollout - LfcFxMPropF - LfcFxVehF - P_LFCFxRolloutOffset;

   /* --- calculation of additional force with secure factor --- */
   LfcFxRollout = (LfcFxDeltaTarRoll * P_LFCSecFacpRollout);
   LfcFxVeh_pVeh.calc(LfcFxRollout);
   LfcpRollout = LfcFxVeh_pVeh.Out_equal_whl(); /* temp var */
   /* limitation to maximal 45 bar */
   LfcpRollout = LfcpRollout.min(P_LFCpRolloutMax);

   /* initialize filter */
   if (LfcFxCtrlNearSSMK1 == true)
   {
     LfcpRolloutF_loc = LfcpRollout;    
   }

   /* ---------------------------------- */
   /* P-T1-Filter of additional pressure */
   /* ---------------------------------- */
   if (LfcpRollout < LfcpRolloutF_loc)
   {  /* reduction filter (strong) */
      LfcFipRollout_loc = P_FipRolloutStrong_b0;
   }
   else
   {   /* buildup filter (weak) */
       LfcFipRollout_loc = P_FipRolloutWeak_b0;
   }

   /* --- filtert target pressure for rollout --- */
   // LfcpRolloutF_loc = LfcpRolloutF_loc + LfcFipRollout_loc * (LfcpRollout - LfcpRolloutF_loc) + (P_OneBit_p/2.0);
   /* rounding construction */
   l_Delta_pRolloutF = LfcpRollout - LfcpRolloutF_loc;
   if (l_Delta_pRolloutF == 0.0)
   {l_pRolloutF_AbsIncr = 0.0;}
   else
   {   /* calculate absolute values of filter increment */
       l_pRolloutF_AbsIncr = LfcFipRollout_loc * (l_Delta_pRolloutF.abs()) + (P_OneBit_p/2.0);
       l_pRolloutF_AbsIncr = l_pRolloutF_AbsIncr.max(P_OneBit_p);
       if (l_Delta_pRolloutF < 0.0)
       {LfcpRolloutF_loc = LfcpRolloutF_loc - l_pRolloutF_AbsIncr;}
       else
       {LfcpRolloutF_loc = LfcpRolloutF_loc + l_pRolloutF_AbsIncr;}
   }

   /* limitation to maximal 45 bar */
   LfcpRolloutF_loc = LfcpRolloutF_loc.min(P_LFCpRolloutMax);
   /* copy to output */
   LfcpRolloutF = LfcpRolloutF_loc;

   /* --- calculation of additional necessary pressure --- */
   /* --- for holding the vehicle --- */
   LfcpDeltaRollout = LfcpRolloutF - pVehAct;   /* pressure difference */

   /* --- calculation of pressure gradient --- */
   LfcDpMaxRollout = LfcpDeltaRollout * P_LFCdtRollout; /* gradient per second */

}
/* no else path - logic only valid if velocity was fast enough */

/* ---------------------- */
/* Activate rollout logic */
/* ---------------------- */
if (LfcSsmVehStop_B == false)
{
   //if (LfcBackwMov_B == true)
   // {
      /* take maximum of default and calculated values */
    //  LfcpRolloutF = LfcpRolloutF.max(P_LFCpBackwRollout);
    //  LfcDpMaxRollout = LfcDpMaxRollout.max(P_LFCDpBackwRollout);
    //  LfcRollout_B = true;
   //}
   if ( (LfcExpVehStop_B == true)
           &&(LfcpRolloutF > pVehAct)
           )
   {
      /* standard case */
      LfcRollout_B = true;
   }
   else if ( (LfcExpVehStop_B == false)
           ||(LfcpRolloutF < (pVehAct - P_LFCpVehHystRollout))
           )
   {
      LfcRollout_B = false;
   }
   else { /* keep last value */}
}
else /* standstill of vehicle */
{
   /* stop pressure increase of rollout logic */
   LfcpRolloutF = LfcpRolloutF.min(pVehAct);
   LfcRollout_B = false;
}

/* assure a minimal gradient for rollout logic */
LfcDpMaxRollout = LfcDpMaxRollout.max(P_LFCDpMinRollout);
/* calculation of pressure gradient per cycle */
LfcDpMaxCycle = LfcDpMaxRollout*C_LDMdT;

/* ------------------------------------ */
/* increase rollout pressure in case of */
/* too high vehicle velocity            */
/* ------------------------------------ */
if ( (vVeh > P_LFCvRolloutMax) 
   &&(LfcRollout_B == true)
   &&(pVehAct > (LfcpRolloutF - (2*LfcDpMaxCycle)))
   )
{
   /* increase rollout pressure up to max 45 bars */
    LfcpRolloutF = (LfcpRolloutF + LfcDpMaxCycle).min(P_LFCpRolloutMax);
}

/* reset values in case of deactivation */
if ((LfcState == LFC_StandBy) && (LfcReqSSM == LFCReqSSM_FxControl))
{
   LfcpRolloutF = 0.0;
   LfcpRolloutF_loc = 0.0;
   LfcDpMaxRollout = 0.0;
   LfcRollout_B = false;
}

LfcFxCtrlNearSSMK1 = LfcFxCtrlNearSSM;

