﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using Microsoft.Office.Interop.Excel;

namespace read_summary_all
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textSheetName_TextChanged(object sender, EventArgs e)
        {

        }

        private void Check_Click(object sender, EventArgs e)
        {
            string sheet_name = textSheetName.Text;
            string filepath_in = textPathSummary.Text;
            string listTask = textTaskID.Text;
            string filepath_out = textPathOutput.Text;
            listTask = listTask.Replace("\r\n", ",");

            string[] tach = listTask.Split(',', '.', '\r', '\n');
            List<string> a = new List<string>();
            a = tach.ToList();
            a = a.Distinct().ToList();

            Microsoft.Office.Interop.Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
            Workbook xlWorkbook = xlApp.Workbooks.Open(filepath_in);

            //Workbook xlWorkbook = xlApp.Workbooks.Open(filepath_in, false, true);
            //Worksheet xlWorksheet = (Worksheet)xlWorkbook.Sheets.get_Item(1);

            //Excel.Application xlApp = new Excel.Application();
            //Excel.Workbook xlWorkbook = xlApp.Workbooks.Open(filepath_in);
            //Excel.Worksheet xlWorksheet = (Excel.Worksheet)xlWorkbook.Sheets.get_Item(1);
            //xlWorksheet22 = (Worksheet)xlWorkbook.Sheets["Test_Spec"];
            Worksheet xlWorksheet = (Worksheet)xlWorkbook.Sheets[sheet_name];
            xlWorksheet.Select(Type.Missing);
            Range xlRange = xlWorksheet.UsedRange;
            object[,] valueArray = (object[,])xlRange.get_Value(XlRangeValueDataType.xlRangeValueDefault);

            int pi = xlWorksheet.UsedRange.Rows.Count;
           // Console.WriteLine(pi + "\n");
            int check = 0;
            int row_package = 0;
            int col_package = 0;
            int row_prj = 0;
            int col_prj = 0;
            int row_status = 0;
            int col_status = 0;
            int row_taskID = 0;
            int col_taskID = 0;
            int row_ItemName = 0;
            int col_ItemName = 0;
            int row_Tester = 0;
            int col_Tester = 0;
            int row_Eloc = 0;
            int col_Eloc = 0;
            int row_opl = 0;
            int col_opl = 0;

            int row_reason_for_code = 0;
            int col_reason_for_code = 0;

            int row_reason_for_fail = 0;
            int col_reason_for_fail = 0;

            int row_remark = 0;
            int col_remark = 0;

            int rowyes = 47;
            int columnyes = 0;

            Microsoft.Office.Interop.Excel.Application xlApp2;
            Workbook xlWorkBook2;
            Worksheet xlWorkSheet2;
            object misValue = System.Reflection.Missing.Value;

            xlApp2 = new Microsoft.Office.Interop.Excel.Application();
            xlWorkBook2 = xlApp2.Workbooks.Add(misValue);
            xlWorkSheet2 = (Worksheet)xlWorkBook2.Worksheets.get_Item(1);
            int rowValue = 1;
            xlWorkSheet2.Cells[rowValue, 1] = "Project";
            xlWorkSheet2.Cells[rowValue, 1].EntireRow.Font.Bold = true;
            xlWorkSheet2.Cells[rowValue, 2] = "TaskID";
            xlWorkSheet2.Cells[rowValue, 2].EntireRow.Font.Bold = true;
            xlWorkSheet2.Cells[rowValue, 3] = "ItemName";
            xlWorkSheet2.Cells[rowValue, 3].EntireRow.Font.Bold = true;
            xlWorkSheet2.Cells[rowValue, 4] = "Tester";
            xlWorkSheet2.Cells[rowValue, 4].EntireRow.Font.Bold = true;
            xlWorkSheet2.Cells[rowValue, 5] = "ELOC Assigned";
            xlWorkSheet2.Cells[rowValue, 5].EntireRow.Font.Bold = true;
            xlWorkSheet2.Cells[rowValue, 6] = "Status";
            xlWorkSheet2.Cells[rowValue, 6].EntireRow.Font.Bold = true;
            xlWorkSheet2.Cells[rowValue, 7] = "Reason For code coverage";
            xlWorkSheet2.Cells[rowValue, 7].EntireRow.Font.Bold = true;
            xlWorkSheet2.Cells[rowValue, 8] = "Reason for Fail Testcase";
            xlWorkSheet2.Cells[rowValue, 8].EntireRow.Font.Bold = true;
            xlWorkSheet2.Cells[rowValue, 9] = "Remark";
            xlWorkSheet2.Cells[rowValue, 9].EntireRow.Font.Bold = true;

            try
            {
                for (int row = 47; row <= xlWorksheet.UsedRange.Rows.Count; ++row)
                {
                    for (int column = 1; column <= xlWorksheet.UsedRange.Columns.Count; ++column)
                    {
                        if (valueArray[row, column] != null)
                        {
                            if (valueArray[row, column].ToString() == "Package")
                            {
                                row_package = row;
                                col_package = column;
                                check++;
                                continue;
                            }

                            else if (valueArray[row, column].ToString() == "Project")
                            {
                                row_prj = row;
                                col_prj = column;
                                check++;
                                continue;
                            }

                            else if (valueArray[row, column].ToString() == "TaskID")
                            {
                                row_taskID = row;
                                col_taskID = column;
                                columnyes = column;
                                check++;
                                continue;
                            }

                            else if (valueArray[row, column].ToString() == "ItemName")
                            {
                                row_ItemName = row;
                                col_ItemName = column;
                                check++;
                                continue;
                            }

                            else if (valueArray[row, column].ToString() == "Tester")
                            {
                                row_Tester = row;
                                col_Tester = column;
                                check++;
                                continue;
                            }

                            else if (valueArray[row, column].ToString() == "ELOC Assigned")
                            {
                                row_Eloc = row;
                                col_Eloc = column;
                                check++;
                                continue;
                            }

                            else if (valueArray[row, column].ToString().Equals("Status Result", StringComparison.Ordinal))
                            {
                                row_status = row;
                                col_status = column;
                                check++;
                                continue;
                            }

                            else if (valueArray[row, column].ToString().Equals("OPL/Defect", StringComparison.Ordinal))
                            {
                                row_opl = row;
                                col_opl = column;
                                check++;
                                continue;
                            }

                            else if (valueArray[row, column].ToString().Equals("Reason For code coverage", StringComparison.Ordinal))
                            {
                                row_reason_for_code = row;
                                col_reason_for_code = column;
                                check++;
                                continue;
                            }

                            else if (valueArray[row, column].ToString().Equals("Reason for Fail Testcase", StringComparison.Ordinal))
                            {
                                row_reason_for_fail = row;
                                col_reason_for_fail = column;
                                check++;
                                continue;
                            }

                            else if (valueArray[row, column].ToString().Equals("Remark", StringComparison.Ordinal))
                            {
                                row_remark = row;
                                col_remark = column;
                                check++;
                                continue;
                            }
                        }
                        if (check == 11) break;
                    }
                }
            }
            catch { }
            rowyes++;
            try
            {
                for (; rowyes <= xlWorksheet.UsedRange.Rows.Count; rowyes++)
                {
                    foreach (string t in a)
                    {
                        if(t!="")
                        {
                            //if (valueArray[rowyes, columnyes] != null)
                            //{
                            if (valueArray[rowyes, columnyes].ToString() == t)
                            {
                                xlWorkSheet2.Cells[++rowValue, 2] = valueArray[rowyes, columnyes].ToString(); // 2 row Task ID
                                xlWorkSheet2.Cells[rowValue, 1] = valueArray[rowyes, col_prj].ToString(); // 1 row Project
                                xlWorkSheet2.Cells[rowValue, 3] = valueArray[rowyes, col_ItemName].ToString(); // 3 row Item Name
                                xlWorkSheet2.Cells[rowValue, 4] = valueArray[rowyes, col_Tester].ToString(); // 4 row Tester
                                if (null != valueArray[rowyes, col_Eloc])
                                {
                                    xlWorkSheet2.Cells[rowValue, 5] = valueArray[rowyes, col_Eloc].ToString(); // 5 row Elocs assign
                                }
                                else
                                {
                                    xlWorkSheet2.Cells[rowValue, 5] = "Check again!!!";
                                    xlWorkSheet2.Cells[rowValue, 5].Interior.Color = XlRgbColor.rgbRed;
                                }

                                if (null != valueArray[rowyes, col_reason_for_code])
                                {
                                    xlWorkSheet2.Cells[rowValue, 7] = valueArray[rowyes, col_reason_for_code].ToString(); // 7 row Reason For code coverage
                                }
                                else if (null == valueArray[rowyes, col_reason_for_code] && valueArray[rowyes, col_status].ToString().Equals("OK", StringComparison.Ordinal))
                                {
                                    xlWorkSheet2.Cells[rowValue, 7] = "-";
                                }
                                else
                                {
                                    xlWorkSheet2.Cells[rowValue, 7] = "Check again!!!";
                                    xlWorkSheet2.Cells[rowValue, 7].Interior.Color = XlRgbColor.rgbRed;

                                }

                                if (null != valueArray[rowyes, col_reason_for_fail])
                                {
                                    xlWorkSheet2.Cells[rowValue, 8] = valueArray[rowyes, col_reason_for_fail].ToString(); // 8 Reason For fail
                                }
                                else if (null == valueArray[rowyes, col_reason_for_fail] && valueArray[rowyes, col_status].ToString().Equals("OK", StringComparison.Ordinal))
                                {
                                    xlWorkSheet2.Cells[rowValue, 8] = "-";
                                }
                                else
                                {
                                    xlWorkSheet2.Cells[rowValue, 8] = "Check again!!!";
                                    xlWorkSheet2.Cells[rowValue, 8].Interior.Color = XlRgbColor.rgbRed;
                                }

                                if (valueArray[rowyes, col_status] == null || valueArray[rowyes, col_opl] == null)
                                {
                                    xlWorkSheet2.Cells[rowValue, 6] = "Check again!!!"; // 6 Status
                                    xlWorkSheet2.Cells[rowValue, 6].Interior.Color = XlRgbColor.rgbRed;
                                }
                                else if (valueArray[rowyes, col_status].ToString().Equals("OK", StringComparison.Ordinal) && valueArray[rowyes, col_opl].ToString().Equals("None", StringComparison.Ordinal))
                                {
                                    xlWorkSheet2.Cells[rowValue, 6] = "Done";
                                }
                                else if (valueArray[rowyes, col_status].ToString().Equals("NG", StringComparison.Ordinal) && valueArray[rowyes, col_opl].ToString().Equals("OPL", StringComparison.Ordinal))
                                {
                                    xlWorkSheet2.Cells[rowValue, 6] = "OPL";
                                    xlWorkSheet2.Cells[rowValue, 6].Interior.Color = XlRgbColor.rgbYellow;
                                }
                                else if (valueArray[rowyes, col_status].ToString().Equals("NG", StringComparison.Ordinal) && valueArray[rowyes, col_opl].ToString().Equals("Defect", StringComparison.Ordinal))
                                {
                                    xlWorkSheet2.Cells[rowValue, 6] = "Defect";
                                    xlWorkSheet2.Cells[rowValue, 6].Interior.Color = XlRgbColor.rgbRed;
                                }


                                //if (valueArray[rowyes, col_Eloc] == null)
                                //{
                                //    xlWorkSheet2.Cells[rowValue, 9] = "Check again" + "\n";
                                //    xlWorkSheet2.Cells[rowValue, 9].Interior.Color = XlRgbColor.rgbRed;
                                //}
                                //if (valueArray[rowyes, col_Eloc-1].ToString() != valueArray[rowyes, col_Eloc].ToString())
                                //{
                                //    xlWorkSheet2.Cells[rowValue, 9] = "Actual ELOCS is " + valueArray[rowyes, col_Eloc].ToString();
                                //}
                                if (null != valueArray[rowyes, col_remark] && valueArray[rowyes, col_Eloc].ToString() != valueArray[rowyes, col_Eloc + 1].ToString())
                                {
                                    xlWorkSheet2.Cells[rowValue, 9] = valueArray[rowyes, col_remark].ToString() + "\n" + "Actual ELOCS is " + valueArray[rowyes, col_Eloc + 1].ToString();
                                }
                                else if (null != valueArray[rowyes, col_remark])
                                {
                                    xlWorkSheet2.Cells[rowValue, 9] = valueArray[rowyes, col_remark].ToString();
                                }
                                else if (valueArray[rowyes, col_Eloc].ToString() != valueArray[rowyes, col_Eloc + 1].ToString())
                                {
                                    xlWorkSheet2.Cells[rowValue, 9] = "Actual ELOCS is " + valueArray[rowyes, col_Eloc + 1].ToString();
                                }
                            }
                        }
                        else
                        {
                            continue;
                        }
                       
                    }
                }
            }
            catch { }

            xlWorkSheet2.Columns.AutoFit();

            //CellRange range = xlWorkSheet2.Range["B2:D4"];

            ((Range)xlWorkSheet2.get_Range("A1:I" + rowValue)).Cells.Borders.LineStyle = XlLineStyle.xlContinuous;
            ((Range)xlWorkSheet2.get_Range("A1:I" + rowValue)).Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignTop;

            try
            {
                xlWorkBook2.SaveAs(filepath_out);
            }

            catch
            {
                //System.Runtime.InteropServices.COMException
                Console.WriteLine("Please close your opening excel file!!!");
                Console.Read();
            }

            xlWorkbook.Close(false,false,false);
            xlApp.Quit();
            System.Runtime.InteropServices.Marshal.ReleaseComObject(xlWorkbook);
            System.Runtime.InteropServices.Marshal.ReleaseComObject(xlWorksheet);
            System.Runtime.InteropServices.Marshal.ReleaseComObject(xlApp);
            xlWorkbook = null;
            xlWorksheet = null;
            xlApp = null;
            GC.Collect();

            xlWorkBook2.Close();
            xlApp2.Quit();
            System.Runtime.InteropServices.Marshal.ReleaseComObject(xlWorkBook2);
            System.Runtime.InteropServices.Marshal.ReleaseComObject(xlWorkSheet2);
            System.Runtime.InteropServices.Marshal.ReleaseComObject(xlApp2);
            xlWorkBook2 = null;
            xlWorkSheet2 = null;
            xlApp2 = null;

            GC.Collect();
            MessageBox.Show("Xong gòi");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textTaskID.Text = Properties.Settings.Default.taskID;
            textPathSummary.Text = Properties.Settings.Default.pathSummary;
            textPathOutput.Text = Properties.Settings.Default.pathOutput;
        }

        private void Form1closed(object sender, FormClosedEventArgs e)
        {
            Properties.Settings.Default.taskID = textTaskID.Text;
            Properties.Settings.Default.pathSummary = textPathSummary.Text;
            Properties.Settings.Default.pathOutput = textPathOutput.Text;
            Properties.Settings.Default.Save();
        }
    }
}
