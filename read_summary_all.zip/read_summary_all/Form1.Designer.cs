﻿namespace read_summary_all
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textSheetName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textTaskID = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textPathSummary = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textPathOutput = new System.Windows.Forms.TextBox();
            this.Check = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textSheetName
            // 
            this.textSheetName.Location = new System.Drawing.Point(21, 46);
            this.textSheetName.Name = "textSheetName";
            this.textSheetName.Size = new System.Drawing.Size(100, 20);
            this.textSheetName.TabIndex = 0;
            this.textSheetName.Text = "Merged_COEM";
            this.textSheetName.TextChanged += new System.EventHandler(this.textSheetName_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Sheet Name";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(18, 95);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Task IDs";
            // 
            // textTaskID
            // 
            this.textTaskID.Location = new System.Drawing.Point(21, 122);
            this.textTaskID.MaximumSize = new System.Drawing.Size(100, 100);
            this.textTaskID.MinimumSize = new System.Drawing.Size(100, 100);
            this.textTaskID.Multiline = true;
            this.textTaskID.Name = "textTaskID";
            this.textTaskID.Size = new System.Drawing.Size(100, 100);
            this.textTaskID.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(18, 254);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(103, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Path of Summary file";
            // 
            // textPathSummary
            // 
            this.textPathSummary.Location = new System.Drawing.Point(21, 281);
            this.textPathSummary.MaximumSize = new System.Drawing.Size(600, 50);
            this.textPathSummary.MinimumSize = new System.Drawing.Size(300, 50);
            this.textPathSummary.Multiline = true;
            this.textPathSummary.Name = "textPathSummary";
            this.textPathSummary.Size = new System.Drawing.Size(396, 50);
            this.textPathSummary.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Cursor = System.Windows.Forms.Cursors.Default;
            this.label3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label3.Location = new System.Drawing.Point(18, 350);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Path of Ouput";
            // 
            // textPathOutput
            // 
            this.textPathOutput.Location = new System.Drawing.Point(21, 377);
            this.textPathOutput.MaximumSize = new System.Drawing.Size(600, 100);
            this.textPathOutput.MinimumSize = new System.Drawing.Size(300, 50);
            this.textPathOutput.Multiline = true;
            this.textPathOutput.Name = "textPathOutput";
            this.textPathOutput.Size = new System.Drawing.Size(396, 50);
            this.textPathOutput.TabIndex = 6;
            // 
            // Check
            // 
            this.Check.Location = new System.Drawing.Point(227, 69);
            this.Check.Name = "Check";
            this.Check.Size = new System.Drawing.Size(101, 64);
            this.Check.TabIndex = 8;
            this.Check.Text = "Check";
            this.Check.UseVisualStyleBackColor = true;
            this.Check.Click += new System.EventHandler(this.Check_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(429, 450);
            this.Controls.Add(this.Check);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textPathOutput);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textPathSummary);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textTaskID);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textSheetName);
            this.Name = "Form1";
            this.Text = "Form1";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1closed);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textSheetName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textTaskID;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textPathSummary;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textPathOutput;
        private System.Windows.Forms.Button Check;
    }
}

