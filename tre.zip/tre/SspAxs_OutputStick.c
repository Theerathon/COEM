// Initialize Monitor encodedErrorRatio and active
ErrorRatio = 0;
Mon_active = false;

//-------- preparing signals ------------------------------------------------------------------------------------------
Ax_local = Ax;                                             // copy to local variable with higer resolution
a_Vehx_local = a_Vehx;
Ax_Max = Ax_local.max(Ax_Max_as_input);                             // Memorise Ax_Max and Ax_Min (calc modulation)
Ax_Min = Ax_local.min(Ax_Min_as_input);
Ax_Range = Ax_Max - Ax_Min;

a_VehxF += (P_fac_a_VehxAxOutput * (a_Vehx_local - a_VehxF_as_input));// Filtering aVehx; Fahrzeugbeschleunigung aus ABS Modul

if (( a_VehxF_Max_as_input - a_VehxF_Min_as_input ) < P_a_VehxG_MMLimit_Ax ) // Limit Model Range, if < 8.0m/s^2
{ 
   a_VehxF_Max = a_VehxF_Max.max(a_VehxF);                 // Memorise a_VehxF_Max and a_VehxF_Min
   a_VehxF_Min = a_VehxF_Min.min(a_VehxF);
}

//-------- Monitoring release -----------------------------------------------------------------------------------------

// Release depentent on ABS activity
ReleasePart_ABS = (   ABS_aktiv
                   &&(tOp_FiltTime_as_input > P_t_Ax_Output_Filt_Time_Su)       // Monitoring is active since 0,5s if ABS control starts
                   &&((a_VehxF.abs()) >= P_a_MidValOutputMon_Su)       // Model modulation >= 4m/s^2 (Suspicious limit)
				   &&(a_VehxF_Max > P_a_VehxG_posMaxAbs ));            // Max model modulation > 1 m/s^2

ReleasePart_noABS = (  !ABS_aktiv 
                     &&((a_VehxF.abs()).between(P_a_MinValOutputMon,P_a_MaxValOutputMon)) // Model modulation: 1.47m/s^2 < a < 12m/s^2
				     &&(a_VehxF_Max > P_a_VehxG_posMax));  // Max model modulation is positive (>0)

// Release general
if (  !SignalAxs_is.ReducedMonitored(AxsQuality)            // Quality of signal shall not be reduced monitored
	&&(!SignalAxs_is.Invalid(AxsQuality) || GC_AxsConstSig ) // Signal quality shall not be invalid or there shall be goodcheck triggered
	&&!SignalAxs_is.NotInitialized(AxsQuality)            // Signal quality shall be initialised
    &&!WssNotOk          										// All wss signals quality is Ok
    &&(Ax_Range <= P_a_No_Mod_Min )                        // Ax_Modulation is lower than ok threshold (0,5m/s^2)
    &&(vF_Min >= P_v_MIN_AX )                              // velocity higher 6m/s
	&&(ReleasePart_ABS || ReleasePart_noABS)               // release condition dependent on ABS-Control
    &&!(Whl_Spin_4WD && ( Ax_Range > P_a_No_Mod_Min )) )   // no wheelspin and lower treshold 1,2m/s^2
{
	Mon_active = true;
}

//-------- Daihatsu specific Monitoring release -----------------------------------------------------------------------
if (!((Diff_Acc_Sen_Mod > P_Diff_Acc_Threshold) || (Grad_Acc_Mod > P_Grad_Threshold)))
{
//Stop the counter
    FOpMon_CancelStore_Extended = true;
}
else
{
//Continue the counter
    FOpMon_CancelStore_Extended = false;
}
	  
//-------- Monitoring  ------------------------------------------------------------------------------------------------
if (   Mon_active 
    && Ax_Range < (P_fac_a_MinAxOutput * (a_VehxF_Max - a_VehxF_Min)) //Signal Modulation is lower 0.36 * Model-Modulation
   )
{
	if ( FOpMon_CancelStore_Extended == false)
	{
		tOp_FiltTime += dT_Ax_Filter_Count;                    // increase Failure counter
		if (ReleasePart_ABS)                                   // during ABS Intervetion
		{
			tOp_FiltTime += dT_Ax_Filter_Count;		           // debounce with double speed
		}
	}
	else
	{
		// counter stop
	}
}
else
{
    tOp_FiltTime = 0;                                      // clear failure counter/debouncing
}

//-------- reset detection if vehicle standstill for at least 3s ------------------------------------------------------
if (vVeh_20ms <= P_v_MIN_StandStill_AX)                    // standstill detected (0,1m/s)
{
	if (standstill_count >= P_standstill_time/2 )			// if the the vehicle has been in standstill for atleast half
	{														// of the standstill time.
		if (!standstill_Memorize_done)						// then the local accelerations at that time are memorized
		{
			a_Vehx_Memorize = a_Vehx_local;					// the local acceleartion signals will be stable during
			Ax_Memorize = Ax_local;							// this time. 
			standstill_Memorize_done = true;				// the memorization is only done once.
		}
	}
	
    if (standstill_count >= P_standstill_time)             				// standstill at least 3s
    {
	    if (!standstill_ini_done )                         				// and reset is not done during this 
		{																// standstill cycle
            a_VehxF_Max = a_VehxF_Min = a_VehxF = a_Vehx_Memorize;  	// set max and min to memorized. value
            Ax_Max = Ax_Min = Ax_Memorize;                          	// set max and min to memorized. value
            Ax_Range = 0;                                  				// reset modulation
            tOp_FiltTime = 0;                              				// reset errorratio
    		standstill_ini_done = true;                    				// remember that standstill values are stored
		}
    }
    else 
	{
		standstill_count += P_dT_Ax;                       // increase standstill counter
        tOp_FiltTime = 0;                                  // stop debouncing (reset errorratio) during standstill
	}
}
else 
{
	standstill_count = 0;                                   // reset counter during drive off
    standstill_ini_done = false;                            // do reset next time, because vehicle is now running
	standstill_Memorize_done = false;						// memorize the values later 
}
//-------- calculate error ratio --------------------------------------------------------------------------------------
ErrorRatio = tOp_FiltTime / P_t_Ax_Output_Filt_Time;       // Set Monitor errorRatio
